import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs";

// Agent orchestration API
export async function GET(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const agents = [
    {
      id: "agent-lead",
      name: "Lead Generation Agent",
      status: "active",
      config: {
        sources: ["linkedin", "crunchbase", "apollo"],
        scrapeFrequency: 6,
        qualificationThreshold: 75,
        targetIndustries: ["SaaS", "AI/ML", "Fintech"],
      },
      metrics: {
        leadsDiscovered: 234,
        qualified: 189,
        enrichmentRate: 94,
        avgScore: 82.4,
      },
    },
    {
      id: "agent-outreach",
      name: "Outreach Agent",
      status: "active",
      config: {
        templates: ["saas-intro", "ai-services", "follow-up"],
        followUpDays: [1, 3, 7],
        maxEmailsPerDay: 200,
      },
      metrics: {
        emailsSent: 1234,
        openRate: 68.4,
        replyRate: 23.1,
        meetingsBooked: 89,
      },
    },
    {
      id: "agent-sales",
      name: "Sales Agent",
      status: "active",
      config: {
        proposalTemplates: ["enterprise", "pro", "starter"],
        autoOnboarding: true,
        pricingStrategy: "value-based",
      },
      metrics: {
        proposalsGenerated: 24,
        conversionRate: 34.2,
        pipelineValue: 284000,
        avgDealSize: 12400,
      },
    },
    {
      id: "agent-support",
      name: "Support Agent",
      status: "active",
      config: {
        knowledgeBase: "full",
        autoResolve: true,
        escalationThreshold: 0.7,
      },
      metrics: {
        ticketsResolved: 156,
        avgResponseTime: 1.2,
        resolutionRate: 94.2,
        escalations: 8,
      },
    },
    {
      id: "agent-content",
      name: "Content Agent",
      status: "active",
      config: {
        platforms: ["blog", "linkedin", "twitter", "youtube"],
        publishSchedule: "daily",
        seoOptimization: true,
      },
      metrics: {
        postsGenerated: 45,
        views: 78900,
        engagement: 12.4,
        growth: 23,
      },
    },
    {
      id: "agent-analytics",
      name: "Analytics Agent",
      status: "active",
      config: {
        kpis: ["mrr", "churn", "ltv", "cac"],
        anomalyDetection: true,
        reportSchedule: "daily",
      },
      metrics: {
        reportsGenerated: 156,
        anomaliesDetected: 12,
        insightsGenerated: 89,
        accuracy: 99.1,
      },
    },
    {
      id: "agent-optimization",
      name: "Optimization Agent",
      status: "idle",
      config: {
        abTesting: true,
        promptOptimization: true,
        workflowTuning: true,
      },
      metrics: {
        testsRun: 34,
        improvements: 12,
        conversionLift: 15.7,
        efficiencyGain: 23.4,
      },
    },
  ];

  return NextResponse.json({ agents });
}

export async function POST(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const { agentId, action, config } = body;

  // Forward to agent orchestrator service
  const response = await fetch(`${process.env.AGENT_ORCHESTRATOR_URL}/agents/${agentId}/${action}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, config }),
  });

  const result = await response.json();
  return NextResponse.json(result);
}