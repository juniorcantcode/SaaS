import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs";

export async function GET(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const period = searchParams.get("period") || "30d";

  const data = {
    kpis: {
      mrr: 28400,
      mrrGrowth: 12.5,
      totalCustomers: 142,
      customerGrowth: 8,
      churnRate: 1.0,
      churnChange: -0.2,
      ltvCac: 4.2,
      ltvCacChange: 0.3,
    },
    revenue: [
      { month: "Jan", revenue: 24000, mrr: 8000 },
      { month: "Feb", revenue: 32000, mrr: 12000 },
      { month: "Mar", revenue: 41000, mrr: 18000 },
      { month: "Apr", revenue: 48000, mrr: 24000 },
      { month: "May", revenue: 52000, mrr: 28000 },
    ],
    agentPerformance: [
      { agent: "Lead Gen", tasks: 234, success: 94, avgTime: "1.2m" },
      { agent: "Outreach", tasks: 156, success: 87, avgTime: "2.4m" },
      { agent: "Sales", tasks: 24, success: 72, avgTime: "5.1m" },
      { agent: "Support", tasks: 89, success: 96, avgTime: "0.8m" },
      { agent: "Content", tasks: 45, success: 91, avgTime: "8.3m" },
      { agent: "Analytics", tasks: 12, success: 99, avgTime: "3.2m" },
    ],
    pipeline: [
      { stage: "Discovery", count: 1240, percentage: 100 },
      { stage: "Qualified", count: 892, percentage: 72 },
      { stage: "Contacted", count: 634, percentage: 52 },
      { stage: "Meeting", count: 189, percentage: 15 },
      { stage: "Proposal", count: 67, percentage: 5 },
      { stage: "Closed", count: 23, percentage: 2 },
    ],
  };

  return NextResponse.json(data);
}

export async function POST(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();

  // Generate custom report
  const response = await fetch(`${process.env.ANALYTICS_ENGINE_URL}/reports/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, ...body }),
  });

  const result = await response.json();
  return NextResponse.json(result);
}