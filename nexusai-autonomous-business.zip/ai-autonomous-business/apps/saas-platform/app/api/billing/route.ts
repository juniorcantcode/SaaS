import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-04-10",
});

export async function GET(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Get subscription details
  const subscriptions = await stripe.subscriptions.list({
    limit: 1,
  });

  const plans = [
    {
      id: "solo",
      name: "Solo Operator",
      price: 97,
      features: ["3 AI Agents", "500 leads/month", "Gmail integration", "Basic analytics"],
    },
    {
      id: "agency",
      name: "AI Automation Agency",
      price: 297,
      features: ["7 AI Agents", "5,000 leads/month", "White-label reports", "Client portals", "Workflow orchestration"],
      popular: true,
    },
    {
      id: "enterprise",
      name: "Autonomous Enterprise",
      price: 997,
      features: ["Unlimited AI Agents", "Unlimited leads", "Custom development", "SLA guarantees", "On-premise deployment"],
    },
  ];

  return NextResponse.json({ plans, currentPlan: "agency" });
}

export async function POST(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const { planId, paymentMethodId } = body;

  // Create subscription
  const subscription = await stripe.subscriptions.create({
    customer: "cus_example",
    items: [{ price: `price_${planId}` }],
    payment_behavior: "default_incomplete",
    expand: ["latest_invoice.payment_intent"],
  });

  return NextResponse.json({ subscription });
}