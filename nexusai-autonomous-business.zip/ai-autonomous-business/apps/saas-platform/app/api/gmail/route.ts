import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs";

export async function GET(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category") || "all";

  const emails = [
    {
      id: "1",
      category: "lead-alerts",
      from: "Lead Generation Agent",
      subject: "12 New Qualified Leads",
      preview: "Discovered 12 new qualified leads from LinkedIn...",
      time: "2026-05-11T10:30:00Z",
      priority: "high",
      unread: true,
    },
    {
      id: "2",
      category: "sales-updates",
      from: "Sales Agent",
      subject: "Proposal Accepted — $24K MRR",
      preview: "TechFlow Inc. has accepted the proposal...",
      time: "2026-05-11T10:15:00Z",
      priority: "high",
      unread: true,
    },
    {
      id: "3",
      category: "daily-reports",
      from: "Analytics Agent",
      subject: "Daily Operations Report",
      preview: "Summary: 234 leads discovered, 189 qualified...",
      time: "2026-05-11T09:00:00Z",
      priority: "medium",
      unread: false,
    },
  ];

  const filtered = category === "all" ? emails : emails.filter(e => e.category === category);

  return NextResponse.json({ emails: filtered, total: filtered.length });
}

export async function POST(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const { to, subject, content, category } = body;

  // Forward to Gmail Hub service
  const response = await fetch(`${process.env.GMAIL_HUB_URL}/send`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, to, subject, content, category }),
  });

  const result = await response.json();
  return NextResponse.json(result);
}