import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs";

export async function GET(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const workflows = [
    {
      id: "wf-001",
      name: "Lead Discovery → Qualification → CRM",
      status: "active",
      steps: [
        { agent: "lead-gen", action: "scrape", status: "completed" },
        { agent: "lead-gen", action: "enrich", status: "completed" },
        { agent: "lead-gen", action: "score", status: "completed" },
        { agent: "crm", action: "insert", status: "completed" },
      ],
      triggers: ["schedule", "manual"],
      lastRun: "2026-05-11T09:00:00Z",
      successRate: 98,
    },
    {
      id: "wf-002",
      name: "Outreach Sequence Automation",
      status: "active",
      steps: [
        { agent: "outreach", action: "generate", status: "completed" },
        { agent: "outreach", action: "send", status: "completed" },
        { agent: "outreach", action: "track", status: "running" },
        { agent: "outreach", action: "follow-up", status: "pending" },
      ],
      triggers: ["new-lead", "manual"],
      lastRun: "2026-05-11T10:30:00Z",
      successRate: 87,
    },
  ];

  return NextResponse.json({ workflows });
}

export async function POST(request: Request) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();

  // Trigger workflow execution
  const response = await fetch(`${process.env.AGENT_ORCHESTRATOR_URL}/workflows/execute`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, ...body }),
  });

  const result = await response.json();
  return NextResponse.json(result);
}