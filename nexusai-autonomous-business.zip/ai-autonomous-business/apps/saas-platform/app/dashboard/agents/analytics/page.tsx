"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { 
  BarChart3, TrendingUp, AlertTriangle, CheckCircle2,
  ArrowUpRight, Clock, Zap, Settings, FileText
} from "lucide-react";
import { useState } from "react";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function AnalyticsAgentPage() {
  const [isActive, setIsActive] = useState(true);

  const stats = [
    { label: "Reports Generated", value: "156", change: "+23", icon: FileText },
    { label: "Anomalies Detected", value: "12", change: "-3", icon: AlertTriangle },
    { label: "Insights Generated", value: "89", change: "+15", icon: Zap },
    { label: "Accuracy", value: "99.1%", change: "+0.3%", icon: CheckCircle2 },
  ];

  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
            <BarChart3 className="w-6 h-6 text-blue-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Analytics & Reporting Agent</h1>
            <p className="text-sm text-muted-foreground">KPI monitoring, anomaly detection, and business intelligence</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg border">
            <span className="text-sm font-medium">Agent Status</span>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
            <Badge variant={isActive ? "default" : "secondary"} className={isActive ? "bg-green-500/10 text-green-500" : ""}>
              {isActive ? "Active" : "Paused"}
            </Badge>
          </div>
          <Button variant="outline" size="icon"><Settings className="w-4 h-4" /></Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <Card className="p-5">
              <div className="flex items-start justify-between">
                <stat.icon className="w-5 h-5 text-blue-500" />
                <Badge variant="secondary" className="text-xs text-green-500 bg-green-500/10">
                  <ArrowUpRight className="w-3 h-3 mr-1" />{stat.change}
                </Badge>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <Card className="p-6">
          <h3 className="font-semibold mb-4">Recent Reports</h3>
          <div className="space-y-3">
            {[
              { name: "Daily Operations Report", type: "daily", generated: "Today 6:00 PM", status: "sent" },
              { name: "Weekly Executive Summary", type: "weekly", generated: "Yesterday 6:00 PM", status: "sent" },
              { name: "Anomaly Alert: Conversion Rate", type: "alert", generated: "2 days ago", status: "resolved" },
              { name: "Monthly Revenue Analysis", type: "monthly", generated: "May 1, 2026", status: "sent" },
            ].map((report, i) => (
              <div key={i} className="flex items-center gap-4 p-4 rounded-lg border">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-500" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{report.name}</span>
                    <Badge variant="secondary" className="text-xs">{report.type}</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">Generated {report.generated}</div>
                </div>
                <Badge variant="secondary" className={`text-xs ${
                  report.status === "sent" ? "bg-green-500/10 text-green-500" : "bg-blue-500/10 text-blue-500"
                }`}>
                  {report.status}
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}