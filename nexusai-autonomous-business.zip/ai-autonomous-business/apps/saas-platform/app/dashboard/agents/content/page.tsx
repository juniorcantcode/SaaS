"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { 
  Globe, FileText, Video, Image, Share2, TrendingUp,
  Zap, Clock, CheckCircle2, Sparkles, BarChart3,
  ArrowUpRight, Play, Pause, Settings, Plus
} from "lucide-react";
import { useState } from "react";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function ContentAgentPage() {
  const [isActive, setIsActive] = useState(true);

  const stats = [
    { label: "Posts Generated", value: "45", change: "+12", icon: FileText },
    { label: "Total Views", value: "78.9K", change: "+23%", icon: TrendingUp },
    { label: "Engagement Rate", value: "12.4%", change: "+2.1%", icon: BarChart3 },
    { label: "Growth", value: "+31%", change: "+8%", icon: ArrowUpRight },
  ];

  const platforms = [
    { name: "Blog/SEO", posts: 45, views: 12400, engagement: 8.2, growth: "+12%", icon: FileText },
    { name: "LinkedIn", posts: 67, views: 18900, engagement: 12.4, growth: "+18%", icon: Share2 },
    { name: "X/Twitter", posts: 134, views: 23400, engagement: 6.8, growth: "+23%", icon: Globe },
    { name: "YouTube", posts: 12, views: 8900, engagement: 15.2, growth: "+31%", icon: Video },
  ];

  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center">
            <Globe className="w-6 h-6 text-amber-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Content Generation Agent</h1>
            <p className="text-sm text-muted-foreground">Multi-platform content production with SEO optimization</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg border">
            <span className="text-sm font-medium">Agent Status</span>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
            <Badge variant={isActive ? "default" : "secondary"} className={isActive ? "bg-green-500/10 text-green-500" : ""}>
              {isActive ? "Active" : "Paused"}
            </Badge>
          </div>
          <Button variant="outline" size="icon"><Settings className="w-4 h-4" /></Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <Card className="p-5">
              <div className="flex items-start justify-between">
                <stat.icon className="w-5 h-5 text-amber-500" />
                <Badge variant="secondary" className="text-xs text-green-500 bg-green-500/10">
                  <ArrowUpRight className="w-3 h-3 mr-1" />{stat.change}
                </Badge>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Platform Performance</h3>
            <div className="space-y-4">
              {platforms.map((platform) => (
                <div key={platform.name} className="flex items-center gap-4 p-4 rounded-lg border">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                    <platform.icon className="w-5 h-5 text-amber-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{platform.name}</span>
                      <Badge variant="secondary" className="text-xs text-green-500 bg-green-500/10">
                        <ArrowUpRight className="w-3 h-3 mr-1" />{platform.growth}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                      <span>{platform.posts} posts</span>
                      <span>{platform.views.toLocaleString()} views</span>
                      <span>{platform.engagement}% engagement</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Content Pipeline</h3>
            <div className="space-y-3">
              {[
                { type: "blog", title: "AI Automation Trends 2026", status: "published", time: "Today 9:00 AM" },
                { type: "linkedin", title: "Scaling to $100K MRR with AI", status: "published", time: "Today 10:30 AM" },
                { type: "twitter", title: "5 AI automation mistakes", status: "scheduled", time: "Today 2:00 PM" },
                { type: "youtube", title: "Building AI Agent Ecosystem", status: "generating", time: "Tomorrow 9:00 AM" },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg border">
                  <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                    item.status === "published" ? "bg-green-500" :
                    item.status === "scheduled" ? "bg-blue-500" : "bg-amber-500 animate-pulse"
                  }`} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{item.title}</span>
                      <Badge variant="secondary" className={`text-xs ${
                        item.status === "published" ? "bg-green-500/10 text-green-500" :
                        item.status === "scheduled" ? "bg-blue-500/10 text-blue-500" :
                        "bg-amber-500/10 text-amber-500"
                      }`}>
                        {item.status}
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">{item.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}