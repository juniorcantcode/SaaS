"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { 
  Target, Play, Pause, Settings, Database, Globe, Filter,
  ArrowUpRight, TrendingUp, Users, Building2, MapPin, DollarSign,
  CheckCircle2, XCircle, Clock, Zap, RefreshCw
} from "lucide-react";
import { useState } from "react";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function LeadAgentPage() {
  const [isActive, setIsActive] = useState(true);
  const [scrapeFrequency, setScrapeFrequency] = useState([6]);
  const [qualificationThreshold, setQualificationThreshold] = useState([75]);

  const stats = [
    { label: "Leads Discovered Today", value: "234", change: "+18%", icon: Target },
    { label: "Qualified Leads", value: "189", change: "+12%", icon: CheckCircle2 },
    { label: "Enrichment Rate", value: "94%", change: "+3%", icon: Database },
    { label: "Avg. Lead Score", value: "82.4", change: "+5.2", icon: TrendingUp },
  ];

  const sources = [
    { name: "LinkedIn Sales Navigator", status: "active", leads: 89, quality: 92 },
    { name: "Crunchbase", status: "active", leads: 45, quality: 88 },
    { name: "Apollo.io", status: "active", leads: 67, quality: 85 },
    { name: "Company Websites", status: "active", leads: 33, quality: 78 },
  ];

  const recentLeads = [
    { company: "TechFlow Inc.", industry: "SaaS", size: "50-200", location: "San Francisco", score: 94, status: "qualified", enriched: true },
    { company: "DataSphere", industry: "AI/ML", size: "200-500", location: "New York", score: 89, status: "qualified", enriched: true },
    { company: "CloudNative Labs", industry: "DevOps", size: "20-50", location: "Austin", score: 87, status: "qualified", enriched: true },
    { company: "SecureStack", industry: "Cybersecurity", size: "100-500", location: "Boston", score: 82, status: "reviewing", enriched: false },
    { company: "FinTech Pro", industry: "Fintech", size: "500+", location: "London", score: 79, status: "reviewing", enriched: false },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
            <Target className="w-6 h-6 text-blue-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Lead Generation Agent</h1>
            <p className="text-sm text-muted-foreground">Autonomous lead discovery, enrichment, and qualification</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg border">
            <span className="text-sm font-medium">Agent Status</span>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
            <Badge variant={isActive ? "default" : "secondary"} className={isActive ? "bg-green-500/10 text-green-500" : ""}>
              {isActive ? "Active" : "Paused"}
            </Badge>
          </div>
          <Button variant="outline" size="icon">
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="p-5">
              <div className="flex items-start justify-between">
                <stat.icon className="w-5 h-5 text-blue-500" />
                <Badge variant="secondary" className="text-xs text-green-500 bg-green-500/10">
                  <ArrowUpRight className="w-3 h-3 mr-1" />{stat.change}
                </Badge>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Configuration */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-1"
        >
          <Card className="p-6">
            <h3 className="font-semibold mb-6 flex items-center gap-2">
              <Settings className="w-4 h-4" /> Agent Configuration
            </h3>

            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium">Scrape Frequency</label>
                  <span className="text-sm text-muted-foreground">{scrapeFrequency[0]}h</span>
                </div>
                <Slider value={scrapeFrequency} onValueChange={setScrapeFrequency} max={24} step={1} />
                <p className="text-xs text-muted-foreground mt-1">How often to scan for new leads</p>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium">Qualification Threshold</label>
                  <span className="text-sm text-muted-foreground">{qualificationThreshold[0]}%</span>
                </div>
                <Slider value={qualificationThreshold} onValueChange={setQualificationThreshold} max={100} step={5} />
                <p className="text-xs text-muted-foreground mt-1">Minimum score to auto-qualify</p>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium">Target Industries</label>
                <div className="flex flex-wrap gap-2">
                  {["SaaS", "AI/ML", "Fintech", "Healthcare", "E-commerce"].map((ind) => (
                    <Badge key={ind} variant="secondary" className="cursor-pointer hover:bg-secondary/80">
                      {ind}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium">Company Size</label>
                <div className="flex flex-wrap gap-2">
                  {["1-10", "11-50", "51-200", "201-500", "500+"].map((size) => (
                    <Badge key={size} variant="secondary" className="cursor-pointer hover:bg-secondary/80">
                      {size}
                    </Badge>
                  ))}
                </div>
              </div>

              <Button className="w-full bg-blue-500 hover:bg-blue-600">
                <RefreshCw className="w-4 h-4 mr-2" /> Update Configuration
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* Sources & Leads */}
        <div className="lg:col-span-2 space-y-6">
          {/* Data Sources */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Globe className="w-4 h-4" /> Active Data Sources
              </h3>
              <div className="grid sm:grid-cols-2 gap-4">
                {sources.map((source) => (
                  <div key={source.name} className="flex items-center gap-4 p-4 rounded-lg border">
                    <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                      <Database className="w-5 h-5 text-blue-500" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{source.name}</span>
                        <Badge variant="secondary" className="text-xs bg-green-500/10 text-green-500">
                          <div className="w-1 h-1 rounded-full bg-green-500 mr-1 animate-pulse" /> Active
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                        <span>{source.leads} leads today</span>
                        <span>Quality: {source.quality}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Recent Leads */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold flex items-center gap-2">
                  <Users className="w-4 h-4" /> Recently Discovered Leads
                </h3>
                <Button variant="ghost" size="sm">View All</Button>
              </div>
              <div className="space-y-3">
                {recentLeads.map((lead) => (
                  <div key={lead.company} className="flex items-center gap-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-bold text-sm">
                      {lead.company[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{lead.company}</span>
                        <Badge variant="secondary" className={`text-xs ${
                          lead.status === "qualified" ? "bg-green-500/10 text-green-500" : "bg-yellow-500/10 text-yellow-500"
                        }`}>
                          {lead.status === "qualified" ? <CheckCircle2 className="w-3 h-3 mr-1" /> : <Clock className="w-3 h-3 mr-1" />}
                          {lead.status}
                        </Badge>
                        {lead.enriched && (
                          <Badge variant="secondary" className="text-xs bg-blue-500/10 text-blue-500">
                            <Database className="w-3 h-3 mr-1" /> Enriched
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1"><Building2 className="w-3 h-3" /> {lead.industry}</span>
                        <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {lead.size}</span>
                        <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {lead.location}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-blue-500">{lead.score}</div>
                      <div className="text-xs text-muted-foreground">Lead Score</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}