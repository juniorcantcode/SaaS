"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { 
  Sparkles, TrendingUp, Zap, FlaskConical, Settings,
  ArrowUpRight, CheckCircle2, Clock, Play
} from "lucide-react";
import { useState } from "react";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function OptimizationAgentPage() {
  const [isActive, setIsActive] = useState(true);

  const stats = [
    { label: "A/B Tests Run", value: "34", change: "+8", icon: FlaskConical },
    { label: "Improvements", value: "12", change: "+3", icon: CheckCircle2 },
    { label: "Conversion Lift", value: "+15.7%", change: "+2.3%", icon: TrendingUp },
    { label: "Efficiency Gain", value: "+23.4%", change: "+5.1%", icon: Zap },
  ];

  const activeTests = [
    { name: "Email Subject Lines", variant_a: "AI Automation for {{company}}", variant_b: "{{company}} + AI = 3x growth", status: "running", days_left: 5, confidence: 78 },
    { name: "Landing Page CTA", variant_a: "Deploy AI Workforce", variant_b: "Start Free Trial", status: "running", days_left: 3, confidence: 65 },
    { name: "Pricing Display", variant_a: "$297/month", variant_b: "$9.90/day", status: "completed", winner: "B", lift: 23 },
  ];

  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-red-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Optimization Agent</h1>
            <p className="text-sm text-muted-foreground">Continuous workflow monitoring and conversion optimization</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg border">
            <span className="text-sm font-medium">Agent Status</span>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
            <Badge variant={isActive ? "default" : "secondary"} className={isActive ? "bg-green-500/10 text-green-500" : ""}>
              {isActive ? "Active" : "Paused"}
            </Badge>
          </div>
          <Button variant="outline" size="icon"><Settings className="w-4 h-4" /></Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <Card className="p-5">
              <div className="flex items-start justify-between">
                <stat.icon className="w-5 h-5 text-red-500" />
                <Badge variant="secondary" className="text-xs text-green-500 bg-green-500/10">
                  <ArrowUpRight className="w-3 h-3 mr-1" />{stat.change}
                </Badge>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Active A/B Tests</h3>
            <Button size="sm" className="bg-red-500 hover:bg-red-600">
              <FlaskConical className="w-4 h-4 mr-2" /> New Test
            </Button>
          </div>
          <div className="space-y-4">
            {activeTests.map((test, i) => (
              <div key={i} className="p-4 rounded-lg border">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-medium text-sm">{test.name}</span>
                  <Badge variant="secondary" className={`text-xs ${
                    test.status === "running" ? "bg-blue-500/10 text-blue-500" : "bg-green-500/10 text-green-500"
                  }`}>
                    {test.status === "running" ? <Clock className="w-3 h-3 mr-1" /> : <CheckCircle2 className="w-3 h-3 mr-1" />}
                    {test.status}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div className="p-3 rounded bg-muted/50">
                    <div className="text-xs text-muted-foreground mb-1">Variant A</div>
                    <div className="text-sm font-medium">{test.variant_a}</div>
                  </div>
                  <div className="p-3 rounded bg-muted/50">
                    <div className="text-xs text-muted-foreground mb-1">Variant B</div>
                    <div className="text-sm font-medium">{test.variant_b}</div>
                  </div>
                </div>
                {test.status === "running" && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span>Confidence: {test.confidence}%</span>
                      <span>{test.days_left} days left</span>
                    </div>
                    <Progress value={test.confidence} className="h-1.5" />
                  </div>
                )}
                {test.status === "completed" && (
                  <div className="flex items-center gap-2 text-sm">
                    <Badge variant="secondary" className="bg-green-500/10 text-green-500">
                      Winner: Variant {test.winner}
                    </Badge>
                    <span className="text-muted-foreground">+{test.lift}% lift</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}