"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { 
  MessageSquare, Mail, Send, Reply, Clock, TrendingUp,
  ArrowUpRight, CheckCircle2, XCircle, AlertCircle, Settings,
  Zap, RefreshCw, BarChart3, Target, Sparkles
} from "lucide-react";
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const sequenceData = [
  { day: "Day 1", sent: 45, opened: 32, replied: 8 },
  { day: "Day 2", sent: 38, opened: 28, replied: 6 },
  { day: "Day 3", sent: 42, opened: 35, replied: 9 },
  { day: "Day 4", sent: 35, opened: 25, replied: 5 },
  { day: "Day 5", sent: 28, opened: 20, replied: 4 },
  { day: "Day 6", sent: 22, opened: 15, replied: 3 },
  { day: "Day 7", sent: 18, opened: 12, replied: 2 },
];

export default function OutreachAgentPage() {
  const [isActive, setIsActive] = useState(true);

  const stats = [
    { label: "Emails Sent Today", value: "234", change: "+15%", icon: Send },
    { label: "Open Rate", value: "68.4%", change: "+4.2%", icon: Mail },
    { label: "Reply Rate", value: "23.1%", change: "+2.8%", icon: Reply },
    { label: "Meetings Booked", value: "12", change: "+5", icon: Target },
  ];

  const templates = [
    { name: "SaaS Introduction", usage: 89, openRate: 72, replyRate: 28, status: "active" },
    { name: "AI Services Pitch", usage: 67, openRate: 68, replyRate: 24, status: "active" },
    { name: "Follow-Up Sequence", usage: 156, openRate: 65, replyRate: 19, status: "active" },
    { name: "Case Study Share", usage: 45, openRate: 74, replyRate: 31, status: "testing" },
  ];

  const recentOutreach = [
    { recipient: "john@techflow.io", subject: "AI automation for TechFlow", status: "opened", time: "2 min ago", opens: 3 },
    { recipient: "sarah@datasphere.com", subject: "Scaling your data pipeline", status: "replied", time: "5 min ago", opens: 1 },
    { recipient: "mike@cloudnative.dev", subject: "DevOps automation proposal", status: "sent", time: "12 min ago", opens: 0 },
    { recipient: "emma@securestack.io", subject: "Security automation audit", status: "opened", time: "18 min ago", opens: 2 },
    { recipient: "david@fintechpro.com", subject: "Fintech compliance automation", status: "replied", time: "25 min ago", opens: 1 },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center">
            <MessageSquare className="w-6 h-6 text-purple-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Outreach Agent</h1>
            <p className="text-sm text-muted-foreground">Personalized cold outreach with automated follow-up sequences</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg border">
            <span className="text-sm font-medium">Agent Status</span>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
            <Badge variant={isActive ? "default" : "secondary"} className={isActive ? "bg-green-500/10 text-green-500" : ""}>
              {isActive ? "Active" : "Paused"}
            </Badge>
          </div>
          <Button variant="outline" size="icon">
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="p-5">
              <div className="flex items-start justify-between">
                <stat.icon className="w-5 h-5 text-purple-500" />
                <Badge variant="secondary" className="text-xs text-green-500 bg-green-500/10">
                  <ArrowUpRight className="w-3 h-3 mr-1" />{stat.change}
                </Badge>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Sequence Performance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="p-6">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <BarChart3 className="w-4 h-4" /> 7-Day Sequence Performance
            </h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={sequenceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px" }} />
                <Bar dataKey="sent" fill="#6366f1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="opened" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="replied" fill="#ec4899" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-6 mt-4 text-xs">
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded bg-indigo-500" /> Sent</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded bg-purple-500" /> Opened</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded bg-pink-500" /> Replied</div>
            </div>
          </Card>
        </motion.div>

        {/* Email Templates */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="p-6">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4" /> AI-Generated Templates
            </h3>
            <div className="space-y-4">
              {templates.map((template) => (
                <div key={template.name} className="p-4 rounded-lg border">
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-medium text-sm">{template.name}</span>
                    <Badge variant="secondary" className={`text-xs ${
                      template.status === "active" ? "bg-green-500/10 text-green-500" : "bg-yellow-500/10 text-yellow-500"
                    }`}>
                      {template.status === "active" ? <CheckCircle2 className="w-3 h-3 mr-1" /> : <AlertCircle className="w-3 h-3 mr-1" />}
                      {template.status}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-xs">
                    <div>
                      <div className="text-muted-foreground">Usage</div>
                      <div className="font-medium">{template.usage}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Open Rate</div>
                      <div className="font-medium text-purple-500">{template.openRate}%</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Reply Rate</div>
                      <div className="font-medium text-pink-500">{template.replyRate}%</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Recent Outreach */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold flex items-center gap-2">
              <Mail className="w-4 h-4" /> Recent Outreach Activity
            </h3>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
          <div className="space-y-2">
            {recentOutreach.map((email, i) => (
              <div key={i} className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                  email.status === "replied" ? "bg-green-500" : 
                  email.status === "opened" ? "bg-blue-500" : "bg-gray-400"
                }`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{email.recipient}</span>
                    <Badge variant="secondary" className={`text-xs ${
                      email.status === "replied" ? "bg-green-500/10 text-green-500" :
                      email.status === "opened" ? "bg-blue-500/10 text-blue-500" :
                      "bg-gray-500/10 text-gray-500"
                    }`}>
                      {email.status === "replied" ? <Reply className="w-3 h-3 mr-1" /> :
                       email.status === "opened" ? <Mail className="w-3 h-3 mr-1" /> :
                       <Clock className="w-3 h-3 mr-1" />}
                      {email.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{email.subject}</p>
                </div>
                <div className="text-right text-xs text-muted-foreground">
                  <div>{email.time}</div>
                  <div>{email.opens} opens</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}