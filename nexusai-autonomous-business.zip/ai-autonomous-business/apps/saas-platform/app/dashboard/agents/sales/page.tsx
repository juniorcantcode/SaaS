"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { 
  Zap, DollarSign, FileText, CheckCircle2, Clock, TrendingUp,
  ArrowUpRight, Users, Target, Sparkles, Send, Settings
} from "lucide-react";
import { useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const pipelineData = [
  { name: "Discovery", value: 35, color: "#6366f1" },
  { name: "Qualified", value: 25, color: "#8b5cf6" },
  { name: "Proposal", value: 20, color: "#ec4899" },
  { name: "Negotiation", value: 12, color: "#f59e0b" },
  { name: "Closed", value: 8, color: "#10b981" },
];

export default function SalesAgentPage() {
  const [isActive, setIsActive] = useState(true);

  const stats = [
    { label: "Proposals Generated", value: "24", change: "+8", icon: FileText },
    { label: "Conversion Rate", value: "34.2%", change: "+5.1%", icon: TrendingUp },
    { label: "Revenue Pipeline", value: "$284K", change: "+12%", icon: DollarSign },
    { label: "Avg. Deal Size", value: "$12.4K", change: "+8%", icon: Target },
  ];

  const proposals = [
    { client: "TechFlow Inc.", value: "$24,000", status: "sent", date: "Today", probability: 85 },
    { client: "DataSphere", value: "$18,500", status: "negotiating", date: "Yesterday", probability: 72 },
    { client: "CloudNative Labs", value: "$12,000", status: "accepted", date: "2 days ago", probability: 100 },
    { client: "SecureStack", value: "$36,000", status: "draft", date: "Today", probability: 45 },
  ];

  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-pink-500/10 flex items-center justify-center">
            <Zap className="w-6 h-6 text-pink-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Sales Agent</h1>
            <p className="text-sm text-muted-foreground">Proposal generation, pricing, and conversion automation</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg border">
            <span className="text-sm font-medium">Agent Status</span>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
            <Badge variant={isActive ? "default" : "secondary"} className={isActive ? "bg-green-500/10 text-green-500" : ""}>
              {isActive ? "Active" : "Paused"}
            </Badge>
          </div>
          <Button variant="outline" size="icon"><Settings className="w-4 h-4" /></Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <Card className="p-5">
              <div className="flex items-start justify-between">
                <stat.icon className="w-5 h-5 text-pink-500" />
                <Badge variant="secondary" className="text-xs text-green-500 bg-green-500/10">
                  <ArrowUpRight className="w-3 h-3 mr-1" />{stat.change}
                </Badge>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Pipeline Distribution</h3>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={pipelineData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                  {pipelineData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {pipelineData.map((item) => (
                <div key={item.name} className="flex items-center gap-2 text-xs">
                  <div className="w-3 h-3 rounded" style={{ backgroundColor: item.color }} />
                  {item.name} ({item.value}%)
                </div>
              ))}
            </div>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Active Proposals</h3>
            <div className="space-y-4">
              {proposals.map((proposal) => (
                <div key={proposal.client} className="p-4 rounded-lg border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm">{proposal.client}</span>
                    <Badge variant="secondary" className={`text-xs ${
                      proposal.status === "accepted" ? "bg-green-500/10 text-green-500" :
                      proposal.status === "sent" ? "bg-blue-500/10 text-blue-500" :
                      proposal.status === "negotiating" ? "bg-yellow-500/10 text-yellow-500" :
                      "bg-gray-500/10 text-gray-500"
                    }`}>
                      {proposal.status}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                    <span>{proposal.value}</span>
                    <span>{proposal.date}</span>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span>Win Probability</span>
                      <span>{proposal.probability}%</span>
                    </div>
                    <Progress value={proposal.probability} className="h-1.5" />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}