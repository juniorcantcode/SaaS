"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { 
  Bot, MessageSquare, CheckCircle2, Clock, AlertTriangle,
  ArrowUpRight, TrendingUp, Users, Settings, Zap
} from "lucide-react";
import { useState } from "react";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function SupportAgentPage() {
  const [isActive, setIsActive] = useState(true);

  const stats = [
    { label: "Tickets Resolved", value: "156", change: "+23", icon: CheckCircle2 },
    { label: "Avg Response Time", value: "1.2m", change: "-30s", icon: Clock },
    { label: "Resolution Rate", value: "94.2%", change: "+2.1%", icon: TrendingUp },
    { label: "Escalations", value: "8", change: "-3", icon: AlertTriangle },
  ];

  const tickets = [
    { id: "#4821", customer: "TechFlow Inc.", issue: "API integration error", status: "resolved", priority: "high", time: "2 min" },
    { id: "#4822", customer: "DataSphere", issue: "Billing inquiry", status: "resolved", priority: "medium", time: "5 min" },
    { id: "#4823", customer: "CloudNative", issue: "Workflow setup help", status: "in-progress", priority: "low", time: "12 min" },
    { id: "#4824", customer: "SecureStack", issue: "Security audit request", status: "escalated", priority: "high", time: "18 min" },
    { id: "#4825", customer: "FinTech Pro", issue: "Custom agent config", status: "in-progress", priority: "medium", time: "25 min" },
  ];

  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center">
            <Bot className="w-6 h-6 text-green-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Customer Support Agent</h1>
            <p className="text-sm text-muted-foreground">Automated FAQ handling, ticket triage, and issue resolution</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg border">
            <span className="text-sm font-medium">Agent Status</span>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
            <Badge variant={isActive ? "default" : "secondary"} className={isActive ? "bg-green-500/10 text-green-500" : ""}>
              {isActive ? "Active" : "Paused"}
            </Badge>
          </div>
          <Button variant="outline" size="icon"><Settings className="w-4 h-4" /></Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <Card className="p-5">
              <div className="flex items-start justify-between">
                <stat.icon className="w-5 h-5 text-green-500" />
                <Badge variant="secondary" className="text-xs text-green-500 bg-green-500/10">
                  <ArrowUpRight className="w-3 h-3 mr-1" />{stat.change}
                </Badge>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold flex items-center gap-2">
              <MessageSquare className="w-4 h-4" /> Active Tickets
            </h3>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
          <div className="space-y-2">
            {tickets.map((ticket) => (
              <div key={ticket.id} className="flex items-center gap-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors">
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                  ticket.priority === "high" ? "bg-red-500" :
                  ticket.priority === "medium" ? "bg-yellow-500" : "bg-blue-500"
                }`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-muted-foreground">{ticket.id}</span>
                    <span className="font-medium text-sm">{ticket.customer}</span>
                    <Badge variant="secondary" className={`text-xs ${
                      ticket.status === "resolved" ? "bg-green-500/10 text-green-500" :
                      ticket.status === "in-progress" ? "bg-blue-500/10 text-blue-500" :
                      "bg-red-500/10 text-red-500"
                    }`}>
                      {ticket.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{ticket.issue}</p>
                </div>
                <div className="text-right text-xs text-muted-foreground">
                  <div>{ticket.time}</div>
                  <div className="capitalize">{ticket.priority} priority</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}