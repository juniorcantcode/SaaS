"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart3, TrendingUp, TrendingDown, Target, Users, DollarSign,
  Zap, ArrowUpRight, ArrowDownRight, Activity, Calendar,
  FileText, Download, Filter
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from "recharts";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const revenueData = [
  { month: "Jan", revenue: 24000, mrr: 8000, churn: 2.1 },
  { month: "Feb", revenue: 32000, mrr: 12000, churn: 1.8 },
  { month: "Mar", revenue: 41000, mrr: 18000, churn: 1.5 },
  { month: "Apr", revenue: 48000, mrr: 24000, churn: 1.2 },
  { month: "May", revenue: 52000, mrr: 28000, churn: 1.0 },
];

const agentPerformance = [
  { agent: "Lead Gen", tasks: 234, success: 94, avgTime: "1.2m" },
  { agent: "Outreach", tasks: 156, success: 87, avgTime: "2.4m" },
  { agent: "Sales", tasks: 24, success: 72, avgTime: "5.1m" },
  { agent: "Support", tasks: 89, success: 96, avgTime: "0.8m" },
  { agent: "Content", tasks: 45, success: 91, avgTime: "8.3m" },
  { agent: "Analytics", tasks: 12, success: 99, avgTime: "3.2m" },
];

export default function AnalyticsPage() {
  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
            <BarChart3 className="w-6 h-6 text-blue-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Analytics & Intelligence</h1>
            <p className="text-sm text-muted-foreground">AI-driven KPI monitoring, anomaly detection, and business insights</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm">
            <Calendar className="w-4 h-4 mr-2" /> Last 30 Days
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" /> Export
          </Button>
        </div>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "MRR", value: "$28,400", change: "+12.5%", trend: "up", icon: DollarSign },
          { label: "Total Customers", value: "142", change: "+8", trend: "up", icon: Users },
          { label: "Churn Rate", value: "1.0%", change: "-0.2%", trend: "down", icon: TrendingDown },
          { label: "LTV/CAC", value: "4.2x", change: "+0.3x", trend: "up", icon: Target },
        ].map((kpi, i) => (
          <motion.div key={kpi.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <Card className="p-5">
              <div className="flex items-start justify-between">
                <kpi.icon className="w-5 h-5 text-blue-500" />
                <Badge variant="secondary" className={`text-xs ${
                  kpi.trend === "up" ? "text-green-500 bg-green-500/10" : "text-green-500 bg-green-500/10"
                }`}>
                  {kpi.trend === "up" ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
                  {kpi.change}
                </Badge>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold">{kpi.value}</div>
                <div className="text-xs text-muted-foreground">{kpi.label}</div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Revenue Growth</h3>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="revGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px" }} />
                <Area type="monotone" dataKey="revenue" stroke="#3b82f6" fill="url(#revGradient)" strokeWidth={2} />
                <Area type="monotone" dataKey="mrr" stroke="#8b5cf6" fill="url(#revGradient)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </motion.div>

        {/* Agent Performance */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Agent Performance Metrics</h3>
            <div className="space-y-4">
              {agentPerformance.map((agent) => (
                <div key={agent.agent} className="flex items-center gap-4">
                  <div className="w-24 text-sm font-medium">{agent.agent}</div>
                  <div className="flex-1">
                    <div className="flex justify-between text-xs mb-1">
                      <span>Success Rate</span>
                      <span>{agent.success}%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full" style={{ width: `${agent.success}%` }} />
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground w-16 text-right">
                    {agent.tasks} tasks
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}