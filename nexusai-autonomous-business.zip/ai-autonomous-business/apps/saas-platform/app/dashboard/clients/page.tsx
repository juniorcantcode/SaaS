"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Users, Plus, Search, Filter, ArrowUpRight, DollarSign,
  TrendingUp, Mail, Phone, Building2, Calendar, MoreHorizontal
} from "lucide-react";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const clients = [
  { name: "TechFlow Inc.", industry: "SaaS", plan: "Enterprise", mrr: "$24,000", status: "active", since: "Mar 2026", health: 95 },
  { name: "DataSphere", industry: "AI/ML", plan: "Pro", mrr: "$12,500", status: "active", since: "Feb 2026", health: 88 },
  { name: "CloudNative Labs", industry: "DevOps", plan: "Pro", mrr: "$8,000", status: "active", since: "Apr 2026", health: 92 },
  { name: "SecureStack", industry: "Cybersecurity", plan: "Enterprise", mrr: "$36,000", status: "onboarding", since: "May 2026", health: 78 },
  { name: "FinTech Pro", industry: "Fintech", plan: "Starter", mrr: "$2,400", status: "active", since: "Jan 2026", health: 85 },
  { name: "HealthAI", industry: "Healthcare", plan: "Pro", mrr: "$15,000", status: "active", since: "Mar 2026", health: 90 },
];

export default function ClientsPage() {
  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-500/10 flex items-center justify-center">
            <Users className="w-6 h-6 text-indigo-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Client Management</h1>
            <p className="text-sm text-muted-foreground">CRM, client health monitoring, and revenue tracking</p>
          </div>
        </div>
        <Button className="bg-gradient-to-r from-indigo-500 to-purple-600">
          <Plus className="w-4 h-4 mr-2" /> Add Client
        </Button>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <Card className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input 
                type="text" 
                placeholder="Search clients..."
                className="w-full h-10 pl-10 pr-4 rounded-md border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="w-4 h-4 mr-2" /> Filter
            </Button>
          </div>

          <div className="space-y-3">
            {clients.map((client) => (
              <div key={client.name} className="flex items-center gap-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-white font-bold text-sm">
                  {client.name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{client.name}</span>
                    <Badge variant="secondary" className={`text-xs ${
                      client.status === "active" ? "bg-green-500/10 text-green-500" : "bg-blue-500/10 text-blue-500"
                    }`}>
                      {client.status}
                    </Badge>
                    <Badge variant="outline" className="text-xs">{client.plan}</Badge>
                  </div>
                  <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Building2 className="w-3 h-3" /> {client.industry}</span>
                    <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> Since {client.since}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-sm">{client.mrr}<span className="text-muted-foreground">/mo</span></div>
                  <div className="text-xs text-muted-foreground">Health: {client.health}%</div>
                </div>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}