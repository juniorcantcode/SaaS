"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Globe, FileText, Video, Image, Share2, TrendingUp,
  Zap, Clock, CheckCircle2, Sparkles, BarChart3,
  ArrowUpRight, Play, Pause, Settings, Plus
} from "lucide-react";
import { useState } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const performanceData = [
  { day: "Mon", views: 1200, engagement: 340, clicks: 89 },
  { day: "Tue", views: 1450, engagement: 420, clicks: 112 },
  { day: "Wed", views: 1100, engagement: 310, clicks: 78 },
  { day: "Thu", views: 1800, engagement: 560, clicks: 156 },
  { day: "Fri", views: 2100, engagement: 680, clicks: 189 },
  { day: "Sat", views: 950, engagement: 280, clicks: 67 },
  { day: "Sun", views: 1300, engagement: 390, clicks: 98 },
];

const contentQueue = [
  { 
    type: "blog", 
    title: "AI Automation Trends 2026: The Complete Guide", 
    platform: "Blog + SEO", 
    status: "published", 
    scheduled: "Today 9:00 AM",
    metrics: { views: 2340, likes: 456, shares: 123 }
  },
  { 
    type: "linkedin", 
    title: "How We Scaled to $100K MRR with AI Agents", 
    platform: "LinkedIn", 
    status: "published", 
    scheduled: "Today 10:30 AM",
    metrics: { views: 1890, likes: 234, shares: 89 }
  },
  { 
    type: "twitter", 
    title: "5 AI automation mistakes killing your growth (thread)", 
    platform: "X/Twitter", 
    status: "scheduled", 
    scheduled: "Today 2:00 PM",
    metrics: null
  },
  { 
    type: "youtube", 
    title: "Building Your First AI Agent Ecosystem", 
    platform: "YouTube", 
    status: "generating", 
    scheduled: "Tomorrow 9:00 AM",
    metrics: null
  },
  { 
    type: "newsletter", 
    title: "Weekly AI Business Intelligence — May 11", 
    platform: "Email", 
    status: "scheduled", 
    scheduled: "Today 6:00 PM",
    metrics: null
  },
];

const platforms = [
  { name: "Blog/SEO", posts: 45, views: 12400, engagement: 8.2, growth: "+12%", icon: FileText },
  { name: "LinkedIn", posts: 67, views: 18900, engagement: 12.4, growth: "+18%", icon: Share2 },
  { name: "X/Twitter", posts: 134, views: 23400, engagement: 6.8, growth: "+23%", icon: Globe },
  { name: "YouTube", posts: 12, views: 8900, engagement: 15.2, growth: "+31%", icon: Video },
  { name: "Instagram", posts: 89, views: 15600, engagement: 9.1, growth: "+15%", icon: Image },
  { name: "Newsletter", posts: 24, views: 6700, engagement: 22.4, growth: "+8%", icon: FileText },
];

export default function ContentPage() {
  const [isActive, setIsActive] = useState(true);

  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center">
            <Globe className="w-6 h-6 text-amber-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Content Engine</h1>
            <p className="text-sm text-muted-foreground">AI-powered content generation, repurposing, and multi-platform publishing</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg border">
            <span className="text-sm font-medium">Engine Status</span>
            <Badge variant="secondary" className="bg-green-500/10 text-green-500">
              <div className="w-1 h-1 rounded-full bg-green-500 mr-1 animate-pulse" /> Active
            </Badge>
          </div>
          <Button className="bg-gradient-to-r from-amber-500 to-orange-600">
            <Plus className="w-4 h-4 mr-2" /> New Campaign
          </Button>
        </div>
      </motion.div>

      {/* Platform Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {platforms.map((platform, i) => (
          <motion.div
            key={platform.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Card className="p-4">
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center mb-3">
                <platform.icon className="w-5 h-5 text-amber-500" />
              </div>
              <div className="text-lg font-bold">{platform.views.toLocaleString()}</div>
              <div className="text-xs text-muted-foreground">{platform.name}</div>
              <Badge variant="secondary" className="text-xs text-green-500 bg-green-500/10 mt-2">
                <ArrowUpRight className="w-3 h-3 mr-1" />{platform.growth}
              </Badge>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Performance Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Content Performance (7 Days)</h3>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={performanceData}>
                <defs>
                  <linearGradient id="viewsGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px" }} />
                <Area type="monotone" dataKey="views" stroke="#f59e0b" fill="url(#viewsGradient)" strokeWidth={2} />
                <Area type="monotone" dataKey="engagement" stroke="#8b5cf6" fill="url(#viewsGradient)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </motion.div>

        {/* Content Queue */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Content Queue</h3>
            <div className="space-y-3">
              {contentQueue.map((item, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg border">
                  <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                    item.status === "published" ? "bg-green-500" :
                    item.status === "scheduled" ? "bg-blue-500" :
                    "bg-amber-500 animate-pulse"
                  }`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm truncate">{item.title}</span>
                      <Badge variant="secondary" className={`text-xs flex-shrink-0 ${
                        item.status === "published" ? "bg-green-500/10 text-green-500" :
                        item.status === "scheduled" ? "bg-blue-500/10 text-blue-500" :
                        "bg-amber-500/10 text-amber-500"
                      }`}>
                        {item.status === "published" ? <CheckCircle2 className="w-3 h-3 mr-1" /> :
                         item.status === "scheduled" ? <Clock className="w-3 h-3 mr-1" /> :
                         <Sparkles className="w-3 h-3 mr-1" />}
                        {item.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{item.platform}</span>
                      <span>{item.scheduled}</span>
                    </div>
                    {item.metrics && (
                      <div className="flex items-center gap-4 mt-2 text-xs">
                        <span className="text-muted-foreground">{item.metrics.views} views</span>
                        <span className="text-muted-foreground">{item.metrics.likes} likes</span>
                        <span className="text-muted-foreground">{item.metrics.shares} shares</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}