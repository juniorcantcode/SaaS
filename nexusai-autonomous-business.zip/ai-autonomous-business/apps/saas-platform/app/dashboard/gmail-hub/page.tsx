"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Mail, Inbox, Send, AlertCircle, CheckCircle2, Clock,
  Zap, BarChart3, TrendingUp, Target, MessageSquare, Bot,
  FileText, Bell, Filter, Search, RefreshCw, Settings
} from "lucide-react";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const emailCategories = [
  { name: "Lead Alerts", count: 12, icon: Target, color: "text-blue-500", bg: "bg-blue-500/10" },
  { name: "Sales Updates", count: 8, icon: TrendingUp, color: "text-pink-500", bg: "bg-pink-500/10" },
  { name: "Daily Reports", count: 1, icon: BarChart3, color: "text-purple-500", bg: "bg-purple-500/10" },
  { name: "Support Tickets", count: 5, icon: MessageSquare, color: "text-green-500", bg: "bg-green-500/10" },
  { name: "System Alerts", count: 3, icon: AlertCircle, color: "text-red-500", bg: "bg-red-500/10" },
  { name: "Content Updates", count: 2, icon: FileText, color: "text-amber-500", bg: "bg-amber-500/10" },
];

const emails = [
  { 
    id: 1, 
    category: "Lead Alerts", 
    from: "Lead Generation Agent", 
    subject: "12 New Qualified Leads — Tech Sector", 
    preview: "Discovered 12 new qualified leads from LinkedIn Sales Navigator. Average lead score: 87.4. Top companies: TechFlow Inc., DataSphere, CloudNative Labs...", 
    time: "2 min ago",
    priority: "high",
    unread: true
  },
  { 
    id: 2, 
    category: "Sales Updates", 
    from: "Sales Agent", 
    subject: "Proposal Accepted — $24K MRR Deal", 
    preview: "TechFlow Inc. has accepted the proposal for Enterprise Automation Package. Contract value: $24,000/month. Onboarding sequence initiated...", 
    time: "15 min ago",
    priority: "high",
    unread: true
  },
  { 
    id: 3, 
    category: "Daily Reports", 
    from: "Analytics Agent", 
    subject: "Daily Operations Report — May 11, 2026", 
    preview: "Summary: 234 leads discovered, 189 qualified, 156 outreach emails sent, 32 opened, 8 replies, 2 meetings booked, $4,200 revenue...", 
    time: "1 hr ago",
    priority: "medium",
    unread: false
  },
  { 
    id: 4, 
    category: "Support Tickets", 
    from: "Support Agent", 
    subject: "Ticket #4821 Resolved — API Integration", 
    preview: "Successfully resolved API integration error for TechFlow Inc. Issue was caused by outdated webhook URL. Updated configuration and verified connectivity...", 
    time: "1 hr ago",
    priority: "medium",
    unread: true
  },
  { 
    id: 5, 
    category: "System Alerts", 
    from: "Optimization Agent", 
    subject: "Content Pipeline Optimized — CTR +23%", 
    preview: "A/B testing complete. New headline format increased click-through rate by 23%. Recommended changes applied to all active content templates...", 
    time: "3 hr ago",
    priority: "low",
    unread: false
  },
  { 
    id: 6, 
    category: "Lead Alerts", 
    from: "Lead Generation Agent", 
    subject: "Enterprise Lead Alert — Fortune 500 Company", 
    preview: "High-value lead detected: Fortune 500 retail company seeking AI automation solutions. Estimated deal size: $150K+. Immediate outreach recommended...", 
    time: "45 min ago",
    priority: "high",
    unread: true
  },
  { 
    id: 7, 
    category: "Sales Updates", 
    from: "Sales Agent", 
    subject: "Meeting Booked — DataSphere Discovery Call", 
    preview: "Discovery call scheduled with DataSphere for May 14, 2026 at 2:00 PM EST. Attendees: Sarah Chen (CTO), Mike Ross (VP Engineering). Calendar invite sent...", 
    time: "1 hr ago",
    priority: "medium",
    unread: true
  },
  { 
    id: 8, 
    category: "Content Updates", 
    from: "Content Agent", 
    subject: "Blog Published — 'AI Automation Trends 2026'", 
    preview: "New blog post published and distributed across LinkedIn, Twitter, and email newsletter. Initial engagement: 234 views, 45 likes, 12 shares...", 
    time: "2 hr ago",
    priority: "low",
    unread: false
  },
];

export default function GmailHubPage() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center">
            <Mail className="w-6 h-6 text-red-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Gmail Operations Hub</h1>
            <p className="text-sm text-muted-foreground">Centralized command center for all AI-generated business intelligence</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" /> Sync Now
          </Button>
          <Button variant="outline" size="sm">
            <Settings className="w-4 h-4 mr-2" /> Configure
          </Button>
        </div>
      </motion.div>

      {/* Category Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {emailCategories.map((cat, i) => (
          <motion.div
            key={cat.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Card className="p-4 cursor-pointer hover:bg-muted/50 transition-colors">
              <div className={`w-10 h-10 rounded-lg ${cat.bg} flex items-center justify-center mb-3`}>
                <cat.icon className={`w-5 h-5 ${cat.color}`} />
              </div>
              <div className="text-2xl font-bold">{cat.count}</div>
              <div className="text-xs text-muted-foreground">{cat.name}</div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Email Feed */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
        <Card className="p-6">
          <Tabs defaultValue="all" className="w-full">
            <div className="flex items-center justify-between mb-4">
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="unread">Unread</TabsTrigger>
                <TabsTrigger value="high">High Priority</TabsTrigger>
                <TabsTrigger value="alerts">Alerts</TabsTrigger>
              </TabsList>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input 
                    type="text" 
                    placeholder="Search emails..."
                    className="h-9 pl-9 pr-4 rounded-md border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 w-64"
                  />
                </div>
                <Button variant="ghost" size="icon">
                  <Filter className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <TabsContent value="all" className="mt-0">
              <ScrollArea className="h-[600px]">
                <div className="space-y-2">
                  {emails.map((email) => (
                    <div 
                      key={email.id} 
                      className={`flex items-start gap-4 p-4 rounded-lg border transition-colors cursor-pointer ${
                        email.unread ? "bg-indigo-500/5 border-indigo-500/20" : "hover:bg-muted/50"
                      }`}
                    >
                      <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                        email.priority === "high" ? "bg-red-500" :
                        email.priority === "medium" ? "bg-yellow-500" : "bg-blue-500"
                      }`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{email.from}</span>
                          <Badge variant="secondary" className="text-xs">
                            {email.category}
                          </Badge>
                          {email.unread && (
                            <Badge variant="default" className="text-xs bg-indigo-500">
                              New
                            </Badge>
                          )}
                        </div>
                        <div className="font-medium text-sm mb-1">{email.subject}</div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{email.preview}</p>
                      </div>
                      <div className="text-right text-xs text-muted-foreground flex-shrink-0">
                        <div>{email.time}</div>
                        <div className="capitalize mt-1">{email.priority} priority</div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="unread" className="mt-0">
              <ScrollArea className="h-[600px]">
                <div className="space-y-2">
                  {emails.filter(e => e.unread).map((email) => (
                    <div 
                      key={email.id} 
                      className="flex items-start gap-4 p-4 rounded-lg border bg-indigo-500/5 border-indigo-500/20 transition-colors cursor-pointer"
                    >
                      <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                        email.priority === "high" ? "bg-red-500" :
                        email.priority === "medium" ? "bg-yellow-500" : "bg-blue-500"
                      }`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{email.from}</span>
                          <Badge variant="secondary" className="text-xs">{email.category}</Badge>
                          <Badge variant="default" className="text-xs bg-indigo-500">New</Badge>
                        </div>
                        <div className="font-medium text-sm mb-1">{email.subject}</div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{email.preview}</p>
                      </div>
                      <div className="text-right text-xs text-muted-foreground flex-shrink-0">
                        <div>{email.time}</div>
                        <div className="capitalize mt-1">{email.priority} priority</div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="high" className="mt-0">
              <ScrollArea className="h-[600px]">
                <div className="space-y-2">
                  {emails.filter(e => e.priority === "high").map((email) => (
                    <div key={email.id} className="flex items-start gap-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors cursor-pointer">
                      <div className="w-2 h-2 rounded-full mt-2 flex-shrink-0 bg-red-500" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{email.from}</span>
                          <Badge variant="secondary" className="text-xs">{email.category}</Badge>
                        </div>
                        <div className="font-medium text-sm mb-1">{email.subject}</div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{email.preview}</p>
                      </div>
                      <div className="text-right text-xs text-muted-foreground flex-shrink-0">
                        <div>{email.time}</div>
                        <div className="capitalize mt-1">high priority</div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="alerts" className="mt-0">
              <ScrollArea className="h-[600px]">
                <div className="space-y-2">
                  {emails.filter(e => e.category === "System Alerts" || e.category === "Lead Alerts").map((email) => (
                    <div key={email.id} className="flex items-start gap-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors cursor-pointer">
                      <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                        email.priority === "high" ? "bg-red-500" : "bg-blue-500"
                      }`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{email.from}</span>
                          <Badge variant="secondary" className="text-xs">{email.category}</Badge>
                        </div>
                        <div className="font-medium text-sm mb-1">{email.subject}</div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{email.preview}</p>
                      </div>
                      <div className="text-right text-xs text-muted-foreground flex-shrink-0">
                        <div>{email.time}</div>
                        <div className="capitalize mt-1">{email.priority} priority</div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </Card>
      </motion.div>
    </div>
  );
}