"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Zap, Bot, Mail, BarChart3, Workflow, Globe, Users, Settings,
  ChevronLeft, ChevronRight, Activity, TrendingUp, Bell,
  Search, Menu, X, Sparkles, Target, MessageSquare, FileText
} from "lucide-react";
import { useUser } from "@clerk/nextjs";

const navItems = [
  { 
    section: "Command Center",
    items: [
      { name: "Overview", href: "/dashboard", icon: Activity, badge: null },
      { name: "Gmail Hub", href: "/dashboard/gmail-hub", icon: Mail, badge: "12 new" },
      { name: "Analytics", href: "/dashboard/analytics", icon: BarChart3, badge: null },
    ]
  },
  {
    section: "AI Agents",
    items: [
      { name: "Lead Generation", href: "/dashboard/agents/lead", icon: Target, badge: "Active", color: "text-blue-500" },
      { name: "Outreach", href: "/dashboard/agents/outreach", icon: MessageSquare, badge: "Active", color: "text-purple-500" },
      { name: "Sales", href: "/dashboard/agents/sales", icon: Zap, badge: "Active", color: "text-pink-500" },
      { name: "Support", href: "/dashboard/agents/support", icon: Bot, badge: "Active", color: "text-green-500" },
      { name: "Content", href: "/dashboard/agents/content", icon: Globe, badge: "Active", color: "text-amber-500" },
      { name: "Analytics Agent", href: "/dashboard/agents/analytics", icon: BarChart3, badge: "Active", color: "text-blue-400" },
      { name: "Optimization", href: "/dashboard/agents/optimization", icon: Sparkles, badge: "Active", color: "text-red-500" },
    ]
  },
  {
    section: "Operations",
    items: [
      { name: "Workflows", href: "/dashboard/workflows", icon: Workflow, badge: null },
      { name: "Content Engine", href: "/dashboard/content", icon: FileText, badge: null },
      { name: "Clients", href: "/dashboard/clients", icon: Users, badge: null },
      { name: "Settings", href: "/dashboard/settings", icon: Settings, badge: null },
    ]
  }
];

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();
  const { user } = useUser();

  return (
    <div className="min-h-screen bg-background flex">
      {/* Mobile overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setMobileOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        className={`fixed lg:static inset-y-0 left-0 z-50 bg-card border-r flex flex-col ${
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        } ${collapsed ? "lg:w-20" : "lg:w-72"} w-72 transition-all duration-300`}
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-4 border-b">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0">
              <Zap className="w-5 h-5 text-white" />
            </div>
            {!collapsed && (
              <motion.span 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="font-bold text-lg"
              >
                NexusAI
              </motion.span>
            )}
          </Link>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              className="hidden lg:flex"
              onClick={() => setCollapsed(!collapsed)}
            >
              {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="lg:hidden"
              onClick={() => setMobileOpen(false)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 py-4">
          {navItems.map((section) => (
            <div key={section.section} className="mb-6">
              {!collapsed && (
                <h3 className="px-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  {section.section}
                </h3>
              )}
              <div className="space-y-1 px-2">
                {section.items.map((item) => {
                  const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
                  return (
                    <Link key={item.name} href={item.href} onClick={() => setMobileOpen(false)}>
                      <Button
                        variant={isActive ? "secondary" : "ghost"}
                        className={`w-full justify-start gap-3 h-10 ${collapsed ? "px-3" : "px-3"} ${
                          isActive ? "bg-secondary" : ""
                        }`}
                      >
                        <item.icon className={`w-4 h-4 flex-shrink-0 ${item.color || ""}`} />
                        {!collapsed && (
                          <>
                            <span className="flex-1 text-left text-sm">{item.name}</span>
                            {item.badge && (
                              <Badge variant={item.badge === "Active" ? "default" : "secondary"} className="text-xs">
                                {item.badge}
                              </Badge>
                            )}
                          </>
                        )}
                      </Button>
                    </Link>
                  );
                })}
              </div>
              <Separator className="mt-4 mx-4" />
            </div>
          ))}
        </ScrollArea>

        {/* User */}
        <div className="p-4 border-t">
          <div className="flex items-center gap-3">
            <Avatar className="w-8 h-8">
              <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white text-xs">
                {user?.firstName?.[0] || "U"}
              </AvatarFallback>
            </Avatar>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user?.fullName || "User"}</p>
                <p className="text-xs text-muted-foreground truncate">{user?.primaryEmailAddress?.emailAddress || ""}</p>
              </div>
            )}
          </div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="h-16 border-b bg-card/50 backdrop-blur-xl flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              className="lg:hidden"
              onClick={() => setMobileOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </Button>
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input 
                type="text" 
                placeholder="Search agents, workflows, clients..."
                className="w-80 h-9 pl-10 pr-4 rounded-md border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
            </Button>
            <Button variant="ghost" size="icon">
              <TrendingUp className="w-5 h-5" />
            </Button>
            <Badge variant="secondary" className="hidden md:flex items-center gap-1 bg-green-500/10 text-green-500 border-green-500/20">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              System Online
            </Badge>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}