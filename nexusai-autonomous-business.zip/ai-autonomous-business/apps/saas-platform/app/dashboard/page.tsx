"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Activity, Users, Mail, TrendingUp, Zap, Bot, BarChart3,
  ArrowUpRight, ArrowDownRight, Clock, CheckCircle2, AlertCircle,
  Target, MessageSquare, Globe, Sparkles, FileText
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from "recharts";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const kpis = [
  { 
    title: "Total Leads", 
    value: "2,847", 
    change: "+12.5%", 
    trend: "up",
    icon: Target,
    color: "text-blue-500",
    bg: "bg-blue-500/10"
  },
  { 
    title: "Outreach Sent", 
    value: "1,234", 
    change: "+8.3%", 
    trend: "up",
    icon: MessageSquare,
    color: "text-purple-500",
    bg: "bg-purple-500/10"
  },
  { 
    title: "Meetings Booked", 
    value: "89", 
    change: "+23.1%", 
    trend: "up",
    icon: Clock,
    color: "text-pink-500",
    bg: "bg-pink-500/10"
  },
  { 
    title: "Revenue", 
    value: "$48.2K", 
    change: "+15.7%", 
    trend: "up",
    icon: TrendingUp,
    color: "text-green-500",
    bg: "bg-green-500/10"
  },
];

const revenueData = [
  { name: "Mon", revenue: 4200, leads: 120 },
  { name: "Tue", revenue: 5100, leads: 145 },
  { name: "Wed", revenue: 4800, leads: 132 },
  { name: "Thu", revenue: 6200, leads: 178 },
  { name: "Fri", revenue: 7500, leads: 210 },
  { name: "Sat", revenue: 3900, leads: 98 },
  { name: "Sun", revenue: 4500, leads: 115 },
];

const agentStatus = [
  { name: "Lead Generation", status: "active", tasks: 24, success: 94, icon: Target, color: "bg-blue-500" },
  { name: "Outreach", status: "active", tasks: 156, success: 87, icon: MessageSquare, color: "bg-purple-500" },
  { name: "Sales", status: "active", tasks: 12, success: 91, icon: Zap, color: "bg-pink-500" },
  { name: "Support", status: "active", tasks: 8, success: 96, icon: Bot, color: "bg-green-500" },
  { name: "Content", status: "active", tasks: 45, success: 89, icon: Globe, color: "bg-amber-500" },
  { name: "Analytics", status: "active", tasks: 6, success: 99, icon: BarChart3, color: "bg-blue-400" },
  { name: "Optimization", status: "idle", tasks: 3, success: 92, icon: Sparkles, color: "bg-red-500" },
];

const recentActivity = [
  { type: "lead", message: "New qualified lead: TechFlow Inc.", time: "2 min ago", status: "success" },
  { type: "outreach", message: "Follow-up sequence completed for 24 leads", time: "15 min ago", status: "success" },
  { type: "sales", message: "Proposal generated for Enterprise client", time: "32 min ago", status: "success" },
  { type: "support", message: "Ticket #4821 resolved automatically", time: "1 hr ago", status: "success" },
  { type: "content", message: "Blog post published: 'AI Automation Trends 2026'", time: "2 hr ago", status: "success" },
  { type: "analytics", message: "Weekly report generated and sent to Gmail", time: "3 hr ago", status: "info" },
];

const pipelineData = [
  { stage: "Discovery", count: 1240, percentage: 100 },
  { stage: "Qualified", count: 892, percentage: 72 },
  { stage: "Contacted", count: 634, percentage: 52 },
  { stage: "Meeting", count: 189, percentage: 15 },
  { stage: "Proposal", count: 67, percentage: 5 },
  { stage: "Closed", count: 23, percentage: 2 },
];

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div 
        initial="initial"
        animate="animate"
        variants={fadeUp}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl font-bold">Command Center</h1>
          <p className="text-muted-foreground mt-1">
            Real-time overview of your autonomous AI business ecosystem
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" size="sm">
            <FileText className="w-4 h-4 mr-2" /> Export Report
          </Button>
          <Button size="sm" className="bg-gradient-to-r from-indigo-500 to-purple-600">
            <Zap className="w-4 h-4 mr-2" /> Run All Agents
          </Button>
        </div>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, i) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="p-6">
              <div className="flex items-start justify-between">
                <div className={`w-10 h-10 rounded-lg ${kpi.bg} flex items-center justify-center`}>
                  <kpi.icon className={`w-5 h-5 ${kpi.color}`} />
                </div>
                <Badge variant="secondary" className={`text-xs ${
                  kpi.trend === "up" ? "text-green-500 bg-green-500/10" : "text-red-500 bg-red-500/10"
                }`}>
                  {kpi.trend === "up" ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
                  {kpi.change}
                </Badge>
              </div>
              <div className="mt-4">
                <div className="text-2xl font-bold">{kpi.value}</div>
                <div className="text-sm text-muted-foreground">{kpi.title}</div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2"
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-semibold">Revenue & Lead Velocity</h3>
                <p className="text-sm text-muted-foreground">Last 7 days performance</p>
              </div>
              <Badge variant="secondary">Real-time</Badge>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="leadsGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "hsl(var(--card))", 
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px"
                  }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#6366f1" fill="url(#revenueGradient)" strokeWidth={2} />
                <Area type="monotone" dataKey="leads" stroke="#8b5cf6" fill="url(#leadsGradient)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </motion.div>

        {/* Pipeline Funnel */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="p-6 h-full">
            <div className="mb-6">
              <h3 className="font-semibold">Pipeline Funnel</h3>
              <p className="text-sm text-muted-foreground">Conversion stages</p>
            </div>
            <div className="space-y-4">
              {pipelineData.map((stage) => (
                <div key={stage.stage}>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{stage.stage}</span>
                    <span className="text-muted-foreground">{stage.count} ({stage.percentage}%)</span>
                  </div>
                  <Progress value={stage.percentage} className="h-2" />
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Agent Status & Activity */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Agent Fleet Status */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-semibold">Agent Fleet Status</h3>
                <p className="text-sm text-muted-foreground">7 agents operational</p>
              </div>
              <Badge variant="secondary" className="bg-green-500/10 text-green-500">
                <div className="w-1.5 h-1.5 rounded-full bg-green-500 mr-1 animate-pulse" />
                All Systems Green
              </Badge>
            </div>
            <div className="space-y-3">
              {agentStatus.map((agent) => (
                <div key={agent.name} className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className={`w-10 h-10 rounded-lg ${agent.color}/10 flex items-center justify-center`}>
                    <agent.icon className={`w-5 h-5 ${agent.color.replace('bg-', 'text-')}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{agent.name}</span>
                      <Badge variant="secondary" className={`text-xs ${
                        agent.status === "active" ? "bg-green-500/10 text-green-500" : "bg-yellow-500/10 text-yellow-500"
                      }`}>
                        {agent.status === "active" ? (
                          <><div className="w-1 h-1 rounded-full bg-green-500 mr-1 animate-pulse" /> Active</>
                        ) : "Idle"}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                      <span>{agent.tasks} tasks queued</span>
                      <span>{agent.success}% success rate</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-semibold">Recent Activity</h3>
                <p className="text-sm text-muted-foreground">Live agent operations</p>
              </div>
              <Button variant="ghost" size="sm">View All</Button>
            </div>
            <div className="space-y-3">
              {recentActivity.map((activity, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                    activity.status === "success" ? "bg-green-500" : "bg-blue-500"
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm">{activity.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}