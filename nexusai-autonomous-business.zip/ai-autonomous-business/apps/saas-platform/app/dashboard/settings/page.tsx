"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Settings, Key, Shield, Bell, Database, Globe, Mail,
  CreditCard, Users, Zap, CheckCircle2, AlertCircle
} from "lucide-react";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

export default function SettingsPage() {
  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-gray-500/10 flex items-center justify-center">
          <Settings className="w-6 h-6 text-gray-500" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">System Settings</h1>
          <p className="text-sm text-muted-foreground">Configure your autonomous business ecosystem</p>
        </div>
      </motion.div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="ai">AI Configuration</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Business Profile</h3>
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Company Name</label>
                  <input type="text" defaultValue="NexusAI Automation" className="w-full h-10 px-3 rounded-md border bg-background text-sm" />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Industry</label>
                  <input type="text" defaultValue="AI Automation Services" className="w-full h-10 px-3 rounded-md border bg-background text-sm" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Business Description</label>
                <textarea defaultValue="Autonomous AI business operating system" className="w-full h-24 px-3 py-2 rounded-md border bg-background text-sm resize-none" />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-semibold mb-4">Notification Preferences</h3>
            <div className="space-y-4">
              {[
                { label: "Lead Alerts", desc: "Get notified when new qualified leads are discovered", enabled: true },
                { label: "Sales Updates", desc: "Notifications for proposal acceptances and meetings", enabled: true },
                { label: "Daily Reports", desc: "Receive daily operational summaries", enabled: true },
                { label: "System Alerts", desc: "Critical system and agent failure notifications", enabled: true },
                { label: "Weekly Executive Summary", desc: "Comprehensive weekly business report", enabled: false },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm">{item.label}</div>
                    <div className="text-xs text-muted-foreground">{item.desc}</div>
                  </div>
                  <Switch defaultChecked={item.enabled} />
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">AI Model Configuration</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                    <Zap className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <div className="font-medium text-sm">OpenAI GPT-4 Turbo</div>
                    <div className="text-xs text-muted-foreground">Primary reasoning engine</div>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-green-500/10 text-green-500">Active</Badge>
              </div>
              <div className="flex items-center justify-between p-4 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                    <Zap className="w-5 h-5 text-purple-500" />
                  </div>
                  <div>
                    <div className="font-medium text-sm">Claude 3 Opus</div>
                    <div className="text-xs text-muted-foreground">Complex reasoning & analysis</div>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-green-500/10 text-green-500">Active</Badge>
              </div>
              <div className="flex items-center justify-between p-4 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Zap className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <div className="font-medium text-sm">Gemini 1.5 Pro</div>
                    <div className="text-xs text-muted-foreground">Multimodal content generation</div>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-green-500/10 text-green-500">Active</Badge>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Connected Services</h3>
            <div className="space-y-4">
              {[
                { name: "Gmail API", desc: "Operations hub & notifications", status: "connected", icon: Mail },
                { name: "Stripe", desc: "Payment processing & billing", status: "connected", icon: CreditCard },
                { name: "Supabase", desc: "Database & authentication", status: "connected", icon: Database },
                { name: "Pinecone", desc: "Vector database for agent memory", status: "connected", icon: Database },
                { name: "n8n", desc: "Workflow automation platform", status: "connected", icon: Zap },
                { name: "LinkedIn API", desc: "Lead generation & content", status: "pending", icon: Globe },
              ].map((integration) => (
                <div key={integration.name} className="flex items-center justify-between p-4 rounded-lg border">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      integration.status === "connected" ? "bg-green-500/10" : "bg-yellow-500/10"
                    }`}>
                      <integration.icon className={`w-5 h-5 ${
                        integration.status === "connected" ? "text-green-500" : "text-yellow-500"
                      }`} />
                    </div>
                    <div>
                      <div className="font-medium text-sm">{integration.name}</div>
                      <div className="text-xs text-muted-foreground">{integration.desc}</div>
                    </div>
                  </div>
                  <Badge variant="secondary" className={`text-xs ${
                    integration.status === "connected" ? "bg-green-500/10 text-green-500" : "bg-yellow-500/10 text-yellow-500"
                  }`}>
                    {integration.status === "connected" ? <CheckCircle2 className="w-3 h-3 mr-1" /> : <AlertCircle className="w-3 h-3 mr-1" />}
                    {integration.status}
                  </Badge>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Security Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-sm">Two-Factor Authentication</div>
                  <div className="text-xs text-muted-foreground">Require 2FA for all admin access</div>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-sm">API Key Rotation</div>
                  <div className="text-xs text-muted-foreground">Auto-rotate API keys every 30 days</div>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-sm">Audit Logging</div>
                  <div className="text-xs text-muted-foreground">Log all agent actions and decisions</div>
                </div>
                <Switch defaultChecked />
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Current Plan</h3>
            <div className="p-6 rounded-lg border bg-gradient-to-br from-indigo-500/5 to-purple-500/5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-xl font-bold">AI Automation Agency</div>
                  <div className="text-sm text-muted-foreground">$297/month — Billed monthly</div>
                </div>
                <Badge variant="secondary" className="bg-indigo-500/10 text-indigo-500">Current Plan</Badge>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Next billing date</div>
                  <div className="font-medium">June 11, 2026</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Payment method</div>
                  <div className="font-medium">•••• 4242</div>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}