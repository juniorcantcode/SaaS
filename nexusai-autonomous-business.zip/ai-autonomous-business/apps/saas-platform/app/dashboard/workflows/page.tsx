"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { 
  Workflow, Play, Pause, GitBranch, ArrowRight, Zap,
  Target, MessageSquare, Bot, Globe, BarChart3, Sparkles,
  Clock, CheckCircle2, AlertCircle, Settings, Plus
} from "lucide-react";
import { useState } from "react";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

const workflows = [
  {
    id: "wf-001",
    name: "Lead Discovery → Qualification → CRM",
    description: "Automatically discovers leads, enriches data, scores them, and inserts into CRM",
    status: "active",
    triggers: ["Schedule (every 6h)", "Manual"],
    steps: [
      { agent: "Lead Generation", action: "Scrape sources", status: "completed" },
      { agent: "Lead Generation", action: "Enrich data", status: "completed" },
      { agent: "Lead Generation", action: "Score leads", status: "completed" },
      { agent: "CRM", action: "Insert qualified", status: "completed" },
    ],
    lastRun: "2 hours ago",
    successRate: 98,
    runsToday: 4,
  },
  {
    id: "wf-002",
    name: "Outreach Sequence Automation",
    description: "Sends personalized emails with automated follow-ups based on engagement",
    status: "active",
    triggers: ["New qualified lead", "Manual"],
    steps: [
      { agent: "Outreach", action: "Generate personalized email", status: "completed" },
      { agent: "Outreach", action: "Send initial outreach", status: "completed" },
      { agent: "Outreach", action: "Track engagement", status: "running" },
      { agent: "Outreach", action: "Send follow-up if no reply", status: "pending" },
    ],
    lastRun: "15 minutes ago",
    successRate: 87,
    runsToday: 156,
  },
  {
    id: "wf-003",
    name: "Sales → Proposal → Onboarding",
    description: "Handles sales conversations, generates proposals, and automates client onboarding",
    status: "active",
    triggers: ["Meeting booked", "Proposal request"],
    steps: [
      { agent: "Sales", action: "Analyze requirements", status: "completed" },
      { agent: "Sales", action: "Generate proposal", status: "completed" },
      { agent: "Sales", action: "Send proposal", status: "completed" },
      { agent: "Sales", action: "Track acceptance", status: "running" },
      { agent: "Onboarding", action: "Setup client portal", status: "pending" },
    ],
    lastRun: "1 hour ago",
    successRate: 72,
    runsToday: 12,
  },
  {
    id: "wf-004",
    name: "Content Production Pipeline",
    description: "Generates, optimizes, and publishes content across all platforms",
    status: "active",
    triggers: ["Schedule (daily 9am)", "Trending topic detected"],
    steps: [
      { agent: "Content", action: "Research trending topics", status: "completed" },
      { agent: "Content", action: "Generate blog post", status: "completed" },
      { agent: "Content", action: "Create social variants", status: "completed" },
      { agent: "Content", action: "SEO optimize", status: "completed" },
      { agent: "Content", action: "Schedule publishing", status: "completed" },
    ],
    lastRun: "3 hours ago",
    successRate: 94,
    runsToday: 3,
  },
  {
    id: "wf-005",
    name: "Daily Analytics & Reporting",
    description: "Compiles KPIs, detects anomalies, and sends executive summary to Gmail",
    status: "active",
    triggers: ["Schedule (daily 6pm)", "Anomaly detected"],
    steps: [
      { agent: "Analytics", action: "Collect metrics", status: "completed" },
      { agent: "Analytics", action: "Detect anomalies", status: "completed" },
      { agent: "Analytics", action: "Generate insights", status: "completed" },
      { agent: "Gmail Hub", action: "Send summary", status: "completed" },
    ],
    lastRun: "6 hours ago",
    successRate: 99,
    runsToday: 1,
  },
  {
    id: "wf-006",
    name: "Support Ticket Auto-Resolution",
    description: "Automatically resolves common support tickets and escalates complex issues",
    status: "active",
    triggers: ["New ticket created", "Manual"],
    steps: [
      { agent: "Support", action: "Classify ticket", status: "completed" },
      { agent: "Support", action: "Search knowledge base", status: "completed" },
      { agent: "Support", action: "Generate response", status: "running" },
      { agent: "Support", action: "Resolve or escalate", status: "pending" },
    ],
    lastRun: "2 minutes ago",
    successRate: 91,
    runsToday: 47,
  },
];

export default function WorkflowsPage() {
  return (
    <div className="space-y-8">
      <motion.div variants={fadeUp} initial="initial" animate="animate" className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-500/10 flex items-center justify-center">
            <Workflow className="w-6 h-6 text-indigo-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Workflow Orchestration</h1>
            <p className="text-sm text-muted-foreground">Multi-agent automation pipelines and DAG orchestration</p>
          </div>
        </div>
        <Button className="bg-gradient-to-r from-indigo-500 to-purple-600">
          <Plus className="w-4 h-4 mr-2" /> Create Workflow
        </Button>
      </motion.div>

      <div className="space-y-4">
        {workflows.map((workflow, i) => (
          <motion.div
            key={workflow.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-start gap-6">
                {/* Workflow Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold">{workflow.name}</h3>
                    <Badge variant="secondary" className="bg-green-500/10 text-green-500 text-xs">
                      <div className="w-1 h-1 rounded-full bg-green-500 mr-1 animate-pulse" />
                      {workflow.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">{workflow.description}</p>

                  {/* Triggers */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="text-xs text-muted-foreground">Triggers:</span>
                    {workflow.triggers.map((trigger) => (
                      <Badge key={trigger} variant="outline" className="text-xs">
                        <Zap className="w-3 h-3 mr-1" />{trigger}
                      </Badge>
                    ))}
                  </div>

                  {/* Steps Pipeline */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {workflow.steps.map((step, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <div className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
                          step.status === "completed" ? "bg-green-500/10 text-green-500" :
                          step.status === "running" ? "bg-blue-500/10 text-blue-500 animate-pulse" :
                          "bg-gray-500/10 text-gray-500"
                        }`}>
                          {step.action}
                        </div>
                        {idx < workflow.steps.length - 1 && (
                          <ArrowRight className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Stats */}
                <div className="flex flex-row lg:flex-col items-center lg:items-end gap-4 lg:gap-2 text-sm">
                  <div className="text-right">
                    <div className="font-medium">{workflow.successRate}%</div>
                    <div className="text-xs text-muted-foreground">Success Rate</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{workflow.runsToday}</div>
                    <div className="text-xs text-muted-foreground">Runs Today</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-muted-foreground">{workflow.lastRun}</div>
                    <div className="text-xs text-muted-foreground">Last Run</div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm">
                      <Play className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Settings className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}