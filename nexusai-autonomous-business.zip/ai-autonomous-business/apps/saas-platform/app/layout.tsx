import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";
import { QueryProvider } from "@/components/providers/query-provider";
import { ThemeProvider } from "@/components/providers/theme-provider";
import { ToastProvider } from "@/components/providers/toast-provider";
import { AgentOrchestratorProvider } from "@/components/providers/agent-orchestrator-provider";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: "NexusAI — Autonomous Business Operating System",
  description: "AI-powered business ecosystem that operates with minimal human intervention. Lead generation, outreach, sales, support, content, analytics — all automated.",
  keywords: ["AI automation", "autonomous business", "AI agents", "workflow automation", "SaaS"],
  authors: [{ name: "NexusAI" }],
  openGraph: {
    title: "NexusAI — Autonomous Business Operating System",
    description: "The future of business is autonomous. Deploy AI agents that work 24/7.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ClerkProvider>
      <html lang="en" suppressHydrationWarning>
        <body className={`${inter.variable} font-sans antialiased`}>
          <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
            <QueryProvider>
              <AgentOrchestratorProvider>
                <ToastProvider />
                {children}
              </AgentOrchestratorProvider>
            </QueryProvider>
          </ThemeProvider>
        </body>
      </html>
    </ClerkProvider>
  );
}