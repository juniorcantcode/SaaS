"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { ArrowRight, Zap, Bot, BarChart3, Mail, Workflow, Shield, Globe } from "lucide-react";
import Link from "next/link";

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
};

const stagger = {
  animate: { transition: { staggerChildren: 0.1 } },
};

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 border-b bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight">NexusAI</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
            <Link href="#features" className="hover:text-foreground transition-colors">Features</Link>
            <Link href="#agents" className="hover:text-foreground transition-colors">AI Agents</Link>
            <Link href="#pricing" className="hover:text-foreground transition-colors">Pricing</Link>
            <Link href="#architecture" className="hover:text-foreground transition-colors">Architecture</Link>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/sign-in">
              <Button variant="ghost" size="sm">Sign In</Button>
            </Link>
            <Link href="/dashboard">
              <Button size="sm" className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700">
                Launch Console <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/5 via-purple-500/5 to-transparent pointer-events-none" />
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial="initial"
            animate="animate"
            variants={stagger}
            className="space-y-8"
          >
            <motion.div variants={fadeUp}>
              <Badge variant="secondary" className="mb-6 px-4 py-2 text-sm bg-indigo-500/10 text-indigo-400 border-indigo-500/20">
                <Zap className="w-3 h-3 mr-2" /> Autonomous AI Business Operating System v2.0
              </Badge>
            </motion.div>

            <motion.h1 
              variants={fadeUp}
              className="text-5xl md:text-7xl font-bold tracking-tight leading-tight"
            >
              Your Business,{" "}
              <span className="gradient-text">Autonomously Operated</span>
              <br />
              by AI Agents
            </motion.h1>

            <motion.p 
              variants={fadeUp}
              className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed"
            >
              Deploy a fleet of intelligent AI agents that handle lead generation, outreach, 
              sales, support, content creation, and analytics — all synchronized through your 
              Gmail hub. Operate 24/7 with minimal human intervention.
            </motion.p>

            <motion.div variants={fadeUp} className="flex flex-wrap justify-center gap-4 pt-4">
              <Link href="/dashboard">
                <Button size="lg" className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-lg px-8">
                  Deploy Your AI Workforce <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="text-lg px-8">
                View Architecture
              </Button>
            </motion.div>

            {/* Stats */}
            <motion.div 
              variants={fadeUp}
              className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-16 max-w-4xl mx-auto"
            >
              {[
                { label: "AI Agents", value: "7", suffix: "+" },
                { label: "Automation Rate", value: "94", suffix: "%" },
                { label: "Avg. Response Time", value: "<2", suffix: "min" },
                { label: "Revenue Uplift", value: "3.2", suffix: "x" },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-3xl md:text-4xl font-bold gradient-text">
                    {stat.value}{stat.suffix}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Agent Ecosystem */}
      <section id="agents" className="py-24 px-6 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Autonomous Agent Ecosystem</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Seven specialized AI agents working in concert, orchestrated through intelligent workflows 
              that adapt and optimize in real-time.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Bot,
                name: "Lead Generation Agent",
                color: "agent-lead",
                desc: "Discovers, enriches, and qualifies leads using multi-source intelligence scraping.",
                features: ["Company intelligence", "Data enrichment", "Qualification scoring", "CRM insertion"],
              },
              {
                icon: Mail,
                name: "Outreach Agent",
                color: "agent-outreach",
                desc: "Generates hyper-personalized cold outreach with automated follow-up sequences.",
                features: ["Personalized emails", "Follow-up automation", "Deliverability optimization", "Gmail integration"],
              },
              {
                icon: Zap,
                name: "Sales Agent",
                color: "agent-sales",
                desc: "Handles pricing, proposals, onboarding automation, and conversion assistance.",
                features: ["Proposal generation", "Pricing explanation", "Onboarding flows", "CRM updates"],
              },
              {
                icon: Shield,
                name: "Support Agent",
                color: "agent-support",
                desc: "Manages FAQ, ticket triage, issue resolution, and intelligent escalation.",
                features: ["FAQ handling", "Ticket triage", "Context memory", "Escalation routing"],
              },
              {
                icon: Globe,
                name: "Content Agent",
                color: "agent-content",
                desc: "Produces SEO-optimized content across all platforms with repurposing pipelines.",
                features: ["Blog generation", "Social media", "SEO optimization", "Multi-platform"],
              },
              {
                icon: BarChart3,
                name: "Analytics Agent",
                color: "agent-analytics",
                desc: "Monitors KPIs, detects anomalies, generates insights, and sends Gmail reports.",
                features: ["KPI monitoring", "Anomaly detection", "AI summaries", "Gmail reporting"],
              },
              {
                icon: Workflow,
                name: "Optimization Agent",
                color: "agent-optimization",
                desc: "Continuously monitors workflows, optimizes prompts, and improves conversions.",
                features: ["Workflow monitoring", "Prompt optimization", "Bottleneck analysis", "A/B testing"],
              },
            ].map((agent, i) => (
              <motion.div
                key={agent.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="agent-card h-full" style={{ "--agent-color": `var(--color-${agent.color})` } as any}>
                  <div className={`w-12 h-12 rounded-xl bg-${agent.color}/10 flex items-center justify-center mb-4`}>
                    <agent.icon className={`w-6 h-6 text-${agent.color}`} />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{agent.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{agent.desc}</p>
                  <div className="flex flex-wrap gap-2">
                    {agent.features.map((f) => (
                      <Badge key={f} variant="secondary" className="text-xs">{f}</Badge>
                    ))}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pipeline Visualization */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">End-to-End Automation Pipeline</h2>
            <p className="text-muted-foreground">
              From lead discovery to retention — every stage automated with intelligent handoffs.
            </p>
          </div>

          <div className="relative">
            <div className="absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-full hidden lg:block" />

            <div className="grid grid-cols-1 md:grid-cols-5 lg:grid-cols-10 gap-4">
              {[
                { stage: "Discovery", icon: Bot, status: "active" },
                { stage: "Qualification", icon: Shield, status: "active" },
                { stage: "CRM Storage", icon: BarChart3, status: "active" },
                { stage: "AI Outreach", icon: Mail, status: "active" },
                { stage: "Follow-Up", icon: Zap, status: "active" },
                { stage: "Booking", icon: Workflow, status: "active" },
                { stage: "Onboarding", icon: Globe, status: "active" },
                { stage: "Payment", icon: Shield, status: "active" },
                { stage: "Delivery", icon: Bot, status: "active" },
                { stage: "Analytics", icon: BarChart3, status: "active" },
              ].map((step, i) => (
                <motion.div
                  key={step.stage}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="relative flex flex-col items-center"
                >
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center z-10 mb-3 ${
                    step.status === "active" 
                      ? "bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg shadow-indigo-500/30" 
                      : "bg-muted"
                  }`}>
                    <step.icon className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-xs font-medium text-center">{step.stage}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Gmail Hub */}
      <section className="py-24 px-6 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <Badge variant="secondary" className="mb-4 bg-red-500/10 text-red-400 border-red-500/20">
                <Mail className="w-3 h-3 mr-2" /> Central Command Center
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Gmail-Centric Operations Hub</h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                All business intelligence flows to your Gmail. Smart categorization, AI-generated summaries, 
                and automated labels transform your inbox into a real-time command center.
              </p>

              <div className="space-y-4">
                {[
                  "Lead notifications with enriched data",
                  "Daily operational reports & KPI summaries",
                  "Payment alerts & revenue tracking",
                  "Customer support update digests",
                  "Appointment confirmations & reminders",
                  "Automation failure alerts with context",
                  "Weekly executive summaries",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-indigo-500" />
                    <span className="text-sm">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 to-purple-500/20 rounded-3xl blur-3xl" />
              <Card className="relative glass-panel p-8">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 pb-4 border-b">
                    <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center">
                      <Mail className="w-5 h-5 text-red-500" />
                    </div>
                    <div>
                      <div className="font-semibold">AI Operations Hub</div>
                      <div className="text-xs text-muted-foreground">nexus-ai@company.com</div>
                    </div>
                  </div>

                  {[
                    { label: "Lead Alert", time: "2 min ago", desc: "3 new qualified leads from Tech sector", color: "bg-blue-500" },
                    { label: "Sales Update", time: "15 min ago", desc: "Proposal accepted — $12K MRR", color: "bg-green-500" },
                    { label: "Daily Report", time: "1 hr ago", desc: "24 outreach sent, 8 replies, 2 meetings", color: "bg-purple-500" },
                    { label: "System Alert", time: "3 hr ago", desc: "Content pipeline optimized — CTR +23%", color: "bg-orange-500" },
                  ].map((email) => (
                    <div key={email.label} className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                      <div className={`w-2 h-2 rounded-full ${email.color} mt-2`} />
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <span className="font-medium text-sm">{email.label}</span>
                          <span className="text-xs text-muted-foreground">{email.time}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">{email.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Scalable Pricing Architecture</h2>
            <p className="text-muted-foreground">
              From solo operator to autonomous enterprise. Scale your AI workforce as you grow.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: "Solo Operator",
                price: "$97",
                period: "/month",
                desc: "Perfect for founders automating their first business",
                features: [
                  "3 AI Agents active",
                  "500 leads/month",
                  "Gmail integration",
                  "Basic analytics",
                  "Community support",
                ],
                cta: "Start Automating",
                popular: false,
              },
              {
                name: "AI Automation Agency",
                price: "$297",
                period: "/month",
                desc: "For agencies managing multiple client automations",
                features: [
                  "7 AI Agents active",
                  "5,000 leads/month",
                  "White-label reports",
                  "Advanced analytics",
                  "Priority support",
                  "Client portals",
                  "Workflow orchestration",
                ],
                cta: "Scale Your Agency",
                popular: true,
              },
              {
                name: "Autonomous Enterprise",
                price: "$997",
                period: "/month",
                desc: "Full autonomous ecosystem for scaling companies",
                features: [
                  "Unlimited AI Agents",
                  "Unlimited leads",
                  "Custom agent development",
                  "Enterprise analytics",
                  "Dedicated success manager",
                  "SLA guarantees",
                  "On-premise deployment",
                  "Advanced security",
                ],
                cta: "Contact Sales",
                popular: false,
              },
            ].map((plan) => (
              <Card 
                key={plan.name}
                className={`relative p-8 ${plan.popular ? 'border-indigo-500 shadow-lg shadow-indigo-500/10' : ''}`}
              >
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white border-0">
                    Most Popular
                  </Badge>
                )}
                <div className="text-center mb-6">
                  <h3 className="text-lg font-semibold mb-2">{plan.name}</h3>
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-muted-foreground">{plan.period}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">{plan.desc}</p>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm">
                      <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button 
                  className={`w-full ${plan.popular ? 'bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700' : ''}`}
                  variant={plan.popular ? "default" : "outline"}
                >
                  {plan.cta}
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Architecture */}
      <section id="architecture" className="py-24 px-6 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Production-Grade Architecture</h2>
            <p className="text-muted-foreground">
              Enterprise AI infrastructure built for scale, security, and reliability.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { category: "Frontend", items: ["Next.js 14", "TypeScript", "Tailwind CSS", "Framer Motion"] },
              { category: "Backend", items: ["FastAPI", "PostgreSQL", "Redis", "Supabase"] },
              { category: "AI Infrastructure", items: ["OpenAI GPT-4", "Claude 3", "LangChain", "CrewAI"] },
              { category: "Orchestration", items: ["n8n", "CrewAI", "AutoGen", "Custom DAG"] },
              { category: "Vector DB", items: ["Pinecone", "pgvector", "Chroma", "Weaviate"] },
              { category: "Hosting", items: ["Vercel", "Docker", "Kubernetes", "AWS/GCP"] },
              { category: "Auth & Security", items: ["Clerk", "JWT", "OAuth 2.0", "Rate Limiting"] },
              { category: "Monitoring", items: ["Sentry", "Prometheus", "Grafana", "LogRocket"] },
            ].map((stack) => (
              <Card key={stack.category} className="p-6">
                <h3 className="font-semibold mb-4 text-sm uppercase tracking-wider text-muted-foreground">
                  {stack.category}
                </h3>
                <div className="space-y-2">
                  {stack.items.map((item) => (
                    <div key={item} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                      <span className="text-sm">{item}</span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="p-12 bg-gradient-to-br from-indigo-500/5 to-purple-500/5 border-indigo-500/20">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready to Deploy Your AI Workforce?
            </h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join the next generation of business operators. Deploy autonomous AI agents that work 
              24/7, scale infinitely, and drive revenue while you focus on strategy.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/dashboard">
                <Button size="lg" className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-lg px-8">
                  Launch NexusAI Console <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-xl">NexusAI</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Autonomous business operating system for the AI-native enterprise.
              </p>
            </div>

            {[
              {
                title: "Product",
                links: ["AI Agents", "Workflows", "Analytics", "Integrations"],
              },
              {
                title: "Resources",
                links: ["Documentation", "API Reference", "Changelog", "Status"],
              },
              {
                title: "Company",
                links: ["About", "Blog", "Careers", "Contact"],
              },
            ].map((section) => (
              <div key={section.title}>
                <h4 className="font-semibold mb-4">{section.title}</h4>
                <ul className="space-y-2">
                  {section.links.map((link) => (
                    <li key={link}>
                      <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                        {link}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © 2026 NexusAI. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm text-muted-foreground">
              <Link href="#" className="hover:text-foreground">Privacy</Link>
              <Link href="#" className="hover:text-foreground">Terms</Link>
              <Link href="#" className="hover:text-foreground">Security</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}