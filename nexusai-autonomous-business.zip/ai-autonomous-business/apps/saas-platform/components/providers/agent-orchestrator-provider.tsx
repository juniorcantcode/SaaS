"use client";

import { createContext, useContext, useState, useCallback } from "react";

interface Agent {
  id: string;
  name: string;
  status: "active" | "idle" | "offline";
  tasks: number;
  successRate: number;
}

interface AgentOrchestratorContextType {
  agents: Agent[];
  isRunning: boolean;
  startAll: () => void;
  stopAll: () => void;
  restartAgent: (id: string) => void;
}

const AgentOrchestratorContext = createContext<AgentOrchestratorContextType | null>(null);

export function AgentOrchestratorProvider({ children }: { children: React.ReactNode }) {
  const [agents, setAgents] = useState<Agent[]>([
    { id: "lead", name: "Lead Generation", status: "active", tasks: 24, successRate: 94 },
    { id: "outreach", name: "Outreach", status: "active", tasks: 156, successRate: 87 },
    { id: "sales", name: "Sales", status: "active", tasks: 12, successRate: 72 },
    { id: "support", name: "Support", status: "active", tasks: 8, successRate: 96 },
    { id: "content", name: "Content", status: "active", tasks: 45, successRate: 89 },
    { id: "analytics", name: "Analytics", status: "active", tasks: 6, successRate: 99 },
    { id: "optimization", name: "Optimization", status: "idle", tasks: 3, successRate: 92 },
  ]);
  const [isRunning, setIsRunning] = useState(true);

  const startAll = useCallback(() => {
    setAgents(prev => prev.map(a => ({ ...a, status: "active" as const })));
    setIsRunning(true);
  }, []);

  const stopAll = useCallback(() => {
    setAgents(prev => prev.map(a => ({ ...a, status: "idle" as const })));
    setIsRunning(false);
  }, []);

  const restartAgent = useCallback((id: string) => {
    setAgents(prev => prev.map(a => a.id === id ? { ...a, status: "active" as const } : a));
  }, []);

  return (
    <AgentOrchestratorContext.Provider value={{ agents, isRunning, startAll, stopAll, restartAgent }}>
      {children}
    </AgentOrchestratorContext.Provider>
  );
}

export function useAgentOrchestrator() {
  const context = useContext(AgentOrchestratorContext);
  if (!context) {
    throw new Error("useAgentOrchestrator must be used within AgentOrchestratorProvider");
  }
  return context;
}