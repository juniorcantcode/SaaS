/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: {
      bodySizeLimit: '2mb',
    },
  },
  images: {
    domains: ['localhost', 'vercel.app', 'supabase.co'],
    remotePatterns: [
      { protocol: 'https', hostname: '**.supabase.co' },
      { protocol: 'https', hostname: '**.stripe.com' },
    ],
  },
  async rewrites() {
    return [
      {
        source: '/api/orchestrator/:path*',
        destination: `${process.env.AGENT_ORCHESTRATOR_URL}/:path*`,
      },
      {
        source: '/api/content/:path*',
        destination: `${process.env.CONTENT_ENGINE_URL}/:path*`,
      },
      {
        source: '/api/analytics/:path*',
        destination: `${process.env.ANALYTICS_ENGINE_URL}/:path*`,
      },
      {
        source: '/api/gmail-hub/:path*',
        destination: `${process.env.GMAIL_HUB_URL}/:path*`,
      },
    ];
  },
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Origin', value: '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET, POST, PUT, DELETE, OPTIONS' },
          { key: 'Access-Control-Allow-Headers', value: 'Content-Type, Authorization' },
        ],
      },
    ];
  },
};

module.exports = nextConfig;