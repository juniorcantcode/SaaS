#!/bin/bash
set -e

echo "🚀 NexusAI Deployment Script"
echo "============================"

ENVIRONMENT=${1:-staging}

echo "Deploying to: $ENVIRONMENT"

# Build SaaS platform
echo "Building SaaS platform..."
cd apps/saas-platform
npm run build
cd ../..

# Build agent orchestrator
echo "Building agent orchestrator..."
cd services/agent-orchestrator
docker build -t nexusai/agent-orchestrator:latest .
cd ../..

# Deploy with Docker Compose
echo "Deploying services..."
if [ "$ENVIRONMENT" = "production" ]; then
    docker-compose -f infrastructure/docker/docker-compose.yml -f infrastructure/docker/docker-compose.prod.yml up -d
else
    docker-compose -f infrastructure/docker/docker-compose.yml up -d
fi

echo ""
echo "✅ Deployment complete!"
echo ""
echo "Services:"
echo "  SaaS Platform: http://localhost:3000"
echo "  Agent API: http://localhost:8000"
echo "  n8n: http://localhost:5678"
echo "  Grafana: http://localhost:3001"
echo ""