#!/bin/bash
set -e

echo "🚀 NexusAI Setup Script"
echo "======================="

# Check prerequisites
echo "Checking prerequisites..."

if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 20+"
    exit 1
fi

if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.11+"
    exit 1
fi

if ! command -v docker &> /dev/null; then
    echo "❌ Docker not found. Please install Docker"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo "❌ Node.js version must be 20+. Current: $(node -v)"
    exit 1
fi

echo "✅ All prerequisites met"

# Install root dependencies
echo "Installing root dependencies..."
npm install

# Install SaaS platform dependencies
echo "Installing SaaS platform dependencies..."
cd apps/saas-platform
npm install
cd ../..

# Install agent orchestrator dependencies
echo "Installing agent orchestrator dependencies..."
cd services/agent-orchestrator
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cd ../..

# Setup environment
echo "Setting up environment..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "⚠️  Please edit .env with your API keys"
fi

# Start infrastructure
echo "Starting infrastructure..."
docker-compose -f infrastructure/docker/docker-compose.yml up -d postgres redis

echo ""
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env with your API keys"
echo "2. Run: npm run dev (starts SaaS platform)"
echo "3. Run: cd services/agent-orchestrator && uvicorn main:app --reload"
echo "4. Open http://localhost:3000"
echo ""
echo "Happy automating! 🤖"