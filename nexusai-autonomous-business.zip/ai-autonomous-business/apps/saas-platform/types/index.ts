export interface Agent {
  id: string;
  name: string;
  description: string;
  status: "active" | "idle" | "offline";
  icon: string;
  color: string;
  metrics: {
    tasksCompleted: number;
    successRate: number;
    avgResponseTime: number;
  };
  config: Record<string, unknown>;
}

export interface Workflow {
  id: string;
  name: string;
  description: string;
  status: "active" | "paused" | "draft";
  triggers: string[];
  steps: WorkflowStep[];
  lastRun: string;
  successRate: number;
  runsToday: number;
}

export interface WorkflowStep {
  agent: string;
  action: string;
  status: "pending" | "running" | "completed" | "failed";
}

export interface Lead {
  id: string;
  company: string;
  industry: string;
  size: string;
  location: string;
  score: number;
  status: "qualified" | "reviewing" | "rejected";
  enriched: boolean;
  source: string;
  discoveredAt: string;
}

export interface Email {
  id: string;
  category: string;
  from: string;
  subject: string;
  preview: string;
  content?: string;
  time: string;
  priority: "high" | "medium" | "low";
  unread: boolean;
}

export interface KPI {
  label: string;
  value: string;
  change: string;
  trend: "up" | "down";
  icon: string;
}

export interface ContentItem {
  id: string;
  type: "blog" | "linkedin" | "twitter" | "youtube" | "newsletter";
  title: string;
  platform: string;
  status: "draft" | "scheduled" | "published";
  scheduled: string;
  metrics?: {
    views: number;
    likes: number;
    shares: number;
  };
}

export interface Client {
  id: string;
  name: string;
  industry: string;
  plan: string;
  mrr: number;
  status: "active" | "onboarding" | "churned";
  since: string;
  health: number;
}

export interface AnalyticsData {
  kpis: {
    mrr: number;
    mrrGrowth: number;
    totalCustomers: number;
    customerGrowth: number;
    churnRate: number;
    churnChange: number;
    ltvCac: number;
    ltvCacChange: number;
  };
  revenue: Array<{ month: string; revenue: number; mrr: number }>;
  agentPerformance: Array<{
    agent: string;
    tasks: number;
    success: number;
    avgTime: string;
  }>;
  pipeline: Array<{
    stage: string;
    count: number;
    percentage: number;
  }>;
}