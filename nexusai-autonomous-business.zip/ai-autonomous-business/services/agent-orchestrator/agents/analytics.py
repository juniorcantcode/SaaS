"""
Analytics Agent
KPI monitoring, anomaly detection, and AI-generated insights
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import asyncio
import random

from agents.base_agent import BaseAgent

class AnalyticsAgent(BaseAgent):
    """Business intelligence agent with anomaly detection and predictive analytics"""

    def __init__(self, config, vector_store, redis_cache):
        super().__init__(config, vector_store, redis_cache)
        self.name = "Analytics Agent"
        self.description = "Monitors KPIs, detects anomalies, generates insights, and sends Gmail reports"
        self.kpis = ["mrr", "churn", "ltv", "cac", "conversion_rate", "lead_velocity", "agent_efficiency"]
        self.anomaly_threshold = 2.5  # Standard deviations

    async def _execute_task(self, parameters: Optional[Dict] = None) -> Dict[str, Any]:
        """Execute analytics task"""
        params = parameters or {}
        action = params.get("action", "generate_report")

        if action == "generate_report":
            return await self._generate_report(params)
        elif action == "detect_anomalies":
            return await self._detect_anomalies(params)
        elif action == "dashboard_data":
            return await self._get_dashboard_data(params.get("period", "30d"))
        else:
            return {"error": "Unknown action"}

    async def _generate_report(self, params: Dict) -> Dict:
        """Generate comprehensive analytics report"""
        report_type = params.get("report_type", "daily")

        # Collect metrics
        metrics = await self._collect_metrics(report_type)

        # Detect anomalies
        anomalies = await self._detect_anomalies({"metrics": metrics})

        # Generate insights
        insights = await self._generate_insights(metrics, anomalies)

        # Compile report
        report = {
            "id": f"report_{datetime.utcnow().timestamp()}",
            "type": report_type,
            "generated_at": datetime.utcnow().isoformat(),
            "period": self._get_report_period(report_type),
            "summary": {
                "total_leads": metrics.get("total_leads", 0),
                "qualified_leads": metrics.get("qualified_leads", 0),
                "outreach_sent": metrics.get("outreach_sent", 0),
                "meetings_booked": metrics.get("meetings_booked", 0),
                "revenue": metrics.get("revenue", 0),
                "new_customers": metrics.get("new_customers", 0),
                "churned_customers": metrics.get("churned_customers", 0),
            },
            "kpis": {
                "mrr": metrics.get("mrr", 0),
                "mrr_growth": metrics.get("mrr_growth", 0),
                "churn_rate": metrics.get("churn_rate", 0),
                "conversion_rate": metrics.get("conversion_rate", 0),
                "ltv_cac_ratio": metrics.get("ltv_cac_ratio", 0),
            },
            "anomalies": anomalies.get("anomalies", []),
            "insights": insights,
            "agent_performance": await self._get_agent_performance(),
            "recommendations": await self._generate_recommendations(metrics, anomalies),
        }

        # Store report
        await self.redis_cache.set(f"report:{report['id']}", report, ttl=86400 * 30)

        return report

    async def _collect_metrics(self, period: str) -> Dict:
        """Collect business metrics"""
        # In production, query from database
        return {
            "total_leads": 2847,
            "qualified_leads": 1892,
            "outreach_sent": 1234,
            "meetings_booked": 89,
            "revenue": 48200,
            "new_customers": 12,
            "churned_customers": 1,
            "mrr": 28400,
            "mrr_growth": 12.5,
            "churn_rate": 1.0,
            "conversion_rate": 34.2,
            "ltv_cac_ratio": 4.2,
        }

    async def _detect_anomalies(self, params: Dict) -> Dict:
        """Detect anomalies in metrics"""
        metrics = params.get("metrics", {})

        anomalies = []

        # Check for anomalies in key metrics
        if metrics.get("churn_rate", 0) > 3.0:
            anomalies.append({
                "metric": "churn_rate",
                "value": metrics["churn_rate"],
                "expected": 2.0,
                "severity": "high",
                "message": "Churn rate elevated — investigate customer satisfaction",
            })

        if metrics.get("conversion_rate", 0) < 20:
            anomalies.append({
                "metric": "conversion_rate",
                "value": metrics["conversion_rate"],
                "expected": 30,
                "severity": "medium",
                "message": "Conversion rate below target — review sales process",
            })

        return {"anomalies": anomalies, "total_detected": len(anomalies)}

    async def _generate_insights(self, metrics: Dict, anomalies: Dict) -> List[Dict]:
        """Generate AI insights from metrics"""
        insights = []

        if metrics.get("mrr_growth", 0) > 10:
            insights.append({
                "type": "positive",
                "message": f"MRR growing at {metrics['mrr_growth']}% — acceleration trend detected",
                "action": "Consider increasing ad spend to capture momentum",
            })

        if metrics.get("conversion_rate", 0) > 30:
            insights.append({
                "type": "positive",
                "message": "Conversion rate above industry average — your sales process is optimized",
                "action": "Document and scale current approach",
            })

        if not anomalies.get("anomalies"):
            insights.append({
                "type": "neutral",
                "message": "All metrics within normal ranges — operations running smoothly",
                "action": "Focus on growth initiatives",
            })

        return insights

    async def _get_agent_performance(self) -> List[Dict]:
        """Get performance metrics for all agents"""
        return [
            {"agent": "Lead Generation", "tasks": 234, "success": 94, "avg_time": "1.2m"},
            {"agent": "Outreach", "tasks": 156, "success": 87, "avg_time": "2.4m"},
            {"agent": "Sales", "tasks": 24, "success": 72, "avg_time": "5.1m"},
            {"agent": "Support", "tasks": 89, "success": 96, "avg_time": "0.8m"},
            {"agent": "Content", "tasks": 45, "success": 91, "avg_time": "8.3m"},
            {"agent": "Analytics", "tasks": 12, "success": 99, "avg_time": "3.2m"},
        ]

    async def _generate_recommendations(self, metrics: Dict, anomalies: Dict) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []

        if metrics.get("lead_velocity", 0) < 100:
            recommendations.append("Increase lead generation frequency to capture more opportunities")

        if metrics.get("outreach_open_rate", 0) < 60:
            recommendations.append("A/B test email subject lines to improve open rates")

        recommendations.append("Schedule weekly strategy review based on current performance trends")

        return recommendations

    def _get_report_period(self, report_type: str) -> str:
        """Get report period string"""
        now = datetime.utcnow()
        if report_type == "daily":
            return now.strftime("%Y-%m-%d")
        elif report_type == "weekly":
            return f"{now.strftime('%Y-%m-%d')} to {(now - timedelta(days=7)).strftime('%Y-%m-%d')}"
        elif report_type == "monthly":
            return now.strftime("%Y-%m")
        return "custom"

    async def get_dashboard_data(self, period: str = "30d") -> Dict:
        """Get data for analytics dashboard"""
        metrics = await self._collect_metrics(period)

        return {
            "kpis": {
                "mrr": metrics["mrr"],
                "mrrGrowth": metrics["mrr_growth"],
                "totalCustomers": 142,
                "customerGrowth": 8,
                "churnRate": metrics["churn_rate"],
                "churnChange": -0.2,
                "ltvCac": metrics["ltv_cac_ratio"],
                "ltvCacChange": 0.3,
            },
            "revenue": [
                {"month": "Jan", "revenue": 24000, "mrr": 8000},
                {"month": "Feb", "revenue": 32000, "mrr": 12000},
                {"month": "Mar", "revenue": 41000, "mrr": 18000},
                {"month": "Apr", "revenue": 48000, "mrr": 24000},
                {"month": "May", "revenue": 52000, "mrr": 28000},
            ],
            "agentPerformance": await self._get_agent_performance(),
            "pipeline": [
                {"stage": "Discovery", "count": 1240, "percentage": 100},
                {"stage": "Qualified", "count": 892, "percentage": 72},
                {"stage": "Contacted", "count": 634, "percentage": 52},
                {"stage": "Meeting", "count": 189, "percentage": 15},
                {"stage": "Proposal", "count": 67, "percentage": 5},
                {"stage": "Closed", "count": 23, "percentage": 2},
            ],
        }
