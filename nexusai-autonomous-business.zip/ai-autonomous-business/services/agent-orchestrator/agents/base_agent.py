"""
Base Agent Class — Foundation for all AI agents
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from datetime import datetime
import asyncio

class BaseAgent(ABC):
    """Base class for all AI agents in the NexusAI ecosystem"""

    def __init__(self, config: Dict[str, Any], vector_store, redis_cache):
        self.config = config
        self.vector_store = vector_store
        self.redis_cache = redis_cache
        self.status = "idle"
        self.name = "Base Agent"
        self.description = "Base agent implementation"
        self.metrics = {
            "tasks_completed": 0,
            "success_rate": 0.0,
            "avg_response_time": 0.0,
            "last_execution": None,
        }
        self.memory = []

    async def initialize(self):
        """Initialize agent resources"""
        self.status = "idle"
        print(f"  ✓ {self.name} initialized")

    async def shutdown(self):
        """Cleanup agent resources"""
        self.status = "offline"

    async def start(self, config: Optional[Dict] = None):
        """Start the agent"""
        self.status = "active"
        if config:
            self.config.update(config)

    async def stop(self):
        """Stop the agent"""
        self.status = "idle"

    async def execute(self, parameters: Optional[Dict] = None) -> Dict[str, Any]:
        """Execute agent task — must be implemented by subclass"""
        start_time = datetime.utcnow()
        self.status = "active"

        try:
            result = await self._execute_task(parameters)

            # Update metrics
            self.metrics["tasks_completed"] += 1
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            self.metrics["avg_response_time"] = (
                (self.metrics["avg_response_time"] * (self.metrics["tasks_completed"] - 1) + execution_time)
                / self.metrics["tasks_completed"]
            )
            self.metrics["last_execution"] = datetime.utcnow().isoformat()

            # Store in memory
            await self._store_memory({
                "timestamp": datetime.utcnow().isoformat(),
                "task": parameters,
                "result": result,
                "execution_time": execution_time,
            })

            return {"success": True, "result": result, "execution_time": execution_time}

        except Exception as e:
            self.metrics["success_rate"] = (
                (self.metrics["success_rate"] * self.metrics["tasks_completed"] + 0)
                / (self.metrics["tasks_completed"] + 1)
            )
            return {"success": False, "error": str(e)}

        finally:
            self.status = "idle"

    @abstractmethod
    async def _execute_task(self, parameters: Optional[Dict] = None) -> Dict[str, Any]:
        """Implement specific task logic in subclass"""
        pass

    async def _store_memory(self, memory_entry: Dict[str, Any]):
        """Store agent memory in vector database"""
        self.memory.append(memory_entry)
        await self.vector_store.store(
            collection=f"agent_{self.name.lower().replace(' ', '_')}_memory",
            data=memory_entry,
        )

    def get_metrics(self) -> Dict[str, Any]:
        """Get agent performance metrics"""
        return {
            **self.metrics,
            "status": self.status,
            "name": self.name,
        }

    async def get_memory(self, query: str, limit: int = 10) -> List[Dict]:
        """Retrieve relevant memories"""
        return await self.vector_store.search(
            collection=f"agent_{self.name.lower().replace(' ', '_')}_memory",
            query=query,
            limit=limit,
        )
