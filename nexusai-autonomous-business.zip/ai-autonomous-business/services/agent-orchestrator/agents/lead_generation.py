"""
Lead Generation Agent
Discovers, enriches, and qualifies leads using multi-source intelligence
"""

from typing import Dict, List, Optional, Any
from datetime import datetime
import asyncio
import random

from agents.base_agent import BaseAgent

class LeadGenerationAgent(BaseAgent):
    """Autonomous lead generation with multi-source scraping and AI qualification"""

    def __init__(self, config, vector_store, redis_cache):
        super().__init__(config, vector_store, redis_cache)
        self.name = "Lead Generation Agent"
        self.description = "Discovers, enriches, and qualifies leads using multi-source intelligence scraping"
        self.sources = ["linkedin", "crunchbase", "apollo", "company_websites"]
        self.qualification_criteria = {
            "min_company_size": 10,
            "target_industries": ["SaaS", "AI/ML", "Fintech", "Healthcare", "E-commerce"],
            "min_funding": 1000000,
        }

    async def _execute_task(self, parameters: Optional[Dict] = None) -> Dict[str, Any]:
        """Execute lead generation pipeline"""
        params = parameters or {}

        # Step 1: Discover leads from sources
        discovered = await self._discover_leads(
            sources=params.get("sources", self.sources),
            max_leads=params.get("max_leads", 100),
        )

        # Step 2: Enrich lead data
        enriched = await self._enrich_leads(discovered)

        # Step 3: Score and qualify
        qualified = await self._qualify_leads(enriched)

        # Step 4: Store in CRM
        await self._store_in_crm(qualified)

        return {
            "discovered": len(discovered),
            "enriched": len(enriched),
            "qualified": len(qualified),
            "leads": qualified,
        }

    async def _discover_leads(self, sources: List[str], max_leads: int) -> List[Dict]:
        """Simulate lead discovery from multiple sources"""
        leads = []
        companies = [
            ("TechFlow Inc.", "SaaS", "50-200", "San Francisco", "Series B"),
            ("DataSphere", "AI/ML", "200-500", "New York", "Series C"),
            ("CloudNative Labs", "DevOps", "20-50", "Austin", "Series A"),
            ("SecureStack", "Cybersecurity", "100-500", "Boston", "Series B"),
            ("FinTech Pro", "Fintech", "500+", "London", "IPO"),
            ("HealthAI", "Healthcare", "50-200", "Berlin", "Series A"),
            ("EcomScale", "E-commerce", "200-500", "Singapore", "Series B"),
            ("DevStream", "SaaS", "20-50", "Toronto", "Seed"),
        ]

        for i, (company, industry, size, location, funding) in enumerate(companies[:max_leads]):
            lead = {
                "id": f"lead_{datetime.utcnow().timestamp()}_{i}",
                "company": company,
                "industry": industry,
                "size": size,
                "location": location,
                "funding_stage": funding,
                "source": random.choice(sources),
                "discovered_at": datetime.utcnow().isoformat(),
                "status": "discovered",
            }
            leads.append(lead)
            await asyncio.sleep(0.01)  # Simulate API call

        return leads

    async def _enrich_leads(self, leads: List[Dict]) -> List[Dict]:
        """Enrich lead data with additional intelligence"""
        enriched = []

        for lead in leads:
            # Simulate data enrichment
            enrichment = {
                "website": f"https://{lead['company'].lower().replace(' ', '').replace('.', '')}.com",
                "linkedin_url": f"https://linkedin.com/company/{lead['company'].lower().replace(' ', '-')}",
                "key_contacts": [
                    {
                        "name": f"Contact at {lead['company']}",
                        "title": "CEO" if random.random() > 0.5 else "CTO",
                        "email": f"contact@{lead['company'].lower().replace(' ', '').replace('.', '')}.com",
                    }
                ],
                "technologies": random.sample(["React", "Python", "AWS", "Kubernetes", "TensorFlow", "Stripe"], 3),
                "recent_news": f"{lead['company']} raised {random.choice(['$5M', '$10M', '$25M', '$50M'])} in {lead['funding_stage']}",
                "enriched_at": datetime.utcnow().isoformat(),
            }

            lead.update(enrichment)
            lead["status"] = "enriched"
            enriched.append(lead)

        return enriched

    async def _qualify_leads(self, leads: List[Dict]) -> List[Dict]:
        """AI-powered lead qualification scoring"""
        qualified = []

        for lead in leads:
            # Calculate qualification score (0-100)
            score = 0

            # Industry match (30 points)
            if lead["industry"] in self.qualification_criteria["target_industries"]:
                score += 30
            else:
                score += 15

            # Company size (25 points)
            size_scores = {"1-10": 10, "11-50": 20, "50-200": 25, "200-500": 25, "500+": 20}
            score += size_scores.get(lead["size"], 15)

            # Funding stage (20 points)
            funding_scores = {"Seed": 15, "Series A": 18, "Series B": 20, "Series C": 20, "IPO": 18}
            score += funding_scores.get(lead["funding_stage"], 15)

            # Data completeness (15 points)
            if lead.get("key_contacts"):
                score += 10
            if lead.get("technologies"):
                score += 5

            # Location (10 points)
            tier1_cities = ["San Francisco", "New York", "London", "Berlin", "Singapore"]
            if lead["location"] in tier1_cities:
                score += 10
            else:
                score += 5

            lead["score"] = min(score, 100)
            lead["qualification_status"] = "qualified" if score >= 75 else "reviewing"
            lead["qualified_at"] = datetime.utcnow().isoformat()

            if score >= 60:  # Include reviewing leads
                qualified.append(lead)

        # Sort by score descending
        qualified.sort(key=lambda x: x["score"], reverse=True)

        return qualified

    async def _store_in_crm(self, leads: List[Dict]):
        """Store qualified leads in CRM via API"""
        for lead in leads:
            await self.redis_cache.set(
                f"lead:{lead['id']}",
                lead,
                ttl=86400 * 30,  # 30 days
            )

    async def discover_leads(self, **kwargs):
        """Public method to trigger lead discovery"""
        return await self.execute(kwargs)

    async def get_leads(self, status=None, industry=None, min_score=None, limit=50):
        """Retrieve leads with filters"""
        # In production, query from CRM/Database
        # For demo, return mock data
        return [
            {
                "id": "lead_001",
                "company": "TechFlow Inc.",
                "industry": "SaaS",
                "size": "50-200",
                "location": "San Francisco",
                "score": 94,
                "status": "qualified",
                "enriched": True,
            },
            {
                "id": "lead_002",
                "company": "DataSphere",
                "industry": "AI/ML",
                "size": "200-500",
                "location": "New York",
                "score": 89,
                "status": "qualified",
                "enriched": True,
            },
        ]
