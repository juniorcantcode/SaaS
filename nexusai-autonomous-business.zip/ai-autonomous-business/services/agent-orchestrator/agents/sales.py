"""
Sales Agent
Handles pricing, proposals, onboarding automation, and conversion
"""

from typing import Dict, List, Optional, Any
from datetime import datetime
import asyncio
import random

from agents.base_agent import BaseAgent

class SalesAgent(BaseAgent):
    """AI sales assistant with proposal generation and onboarding automation"""

    def __init__(self, config, vector_store, redis_cache):
        super().__init__(config, vector_store, redis_cache)
        self.name = "Sales Agent"
        self.description = "Handles pricing explanation, proposal generation, onboarding automation, and conversion"
        self.proposal_templates = {
            "enterprise": {
                "name": "Enterprise Automation Package",
                "price": 24000,
                "period": "monthly",
                "features": [
                    "Unlimited AI Agents",
                    "Custom workflow development",
                    "Dedicated success manager",
                    "SLA guarantees (99.9% uptime)",
                    "On-premise deployment option",
                    "Advanced security & compliance",
                    "Priority support (24/7)",
                    "Quarterly business reviews",
                ],
            },
            "pro": {
                "name": "Professional Package",
                "price": 8000,
                "period": "monthly",
                "features": [
                    "7 AI Agents",
                    "Workflow orchestration",
                    "Client portals",
                    "White-label reports",
                    "Advanced analytics",
                    "Priority support",
                    "API access",
                ],
            },
            "starter": {
                "name": "Starter Package",
                "price": 2400,
                "period": "monthly",
                "features": [
                    "3 AI Agents",
                    "Basic automation",
                    "Gmail integration",
                    "Standard analytics",
                    "Community support",
                ],
            },
        }

    async def _execute_task(self, parameters: Optional[Dict] = None) -> Dict[str, Any]:
        """Execute sales task"""
        params = parameters or {}
        action = params.get("action", "generate_proposal")

        if action == "generate_proposal":
            return await self._generate_proposal(params)
        elif action == "explain_pricing":
            return await self._explain_pricing(params)
        elif action == "onboard_client":
            return await self._onboard_client(params)
        else:
            return {"error": "Unknown action"}

    async def _generate_proposal(self, params: Dict) -> Dict:
        """Generate customized proposal"""
        client_id = params.get("client_id")
        package = params.get("package", "enterprise")

        template = self.proposal_templates.get(package, self.proposal_templates["pro"])

        # Customize based on client needs
        proposal = {
            "id": f"prop_{datetime.utcnow().timestamp()}",
            "client_id": client_id,
            "package": package,
            "title": template["name"],
            "price": template["price"],
            "period": template["period"],
            "features": template["features"],
            "customizations": [
                "Tailored to your industry-specific needs",
                "Integration with your existing tech stack",
                "Custom agent training on your data",
            ],
            "valid_until": (datetime.utcnow() + timedelta(days=30)).isoformat(),
            "generated_at": datetime.utcnow().isoformat(),
            "status": "draft",
        }

        # Store proposal
        await self.redis_cache.set(
            f"proposal:{proposal['id']}",
            proposal,
            ttl=86400 * 30,
        )

        return proposal

    async def _explain_pricing(self, params: Dict) -> Dict:
        """Generate pricing explanation"""
        package = params.get("package", "enterprise")
        template = self.proposal_templates.get(package)

        explanation = {
            "package": package,
            "base_price": template["price"],
            "roi_projection": {
                "time_saved_per_month": "120 hours",
                "cost_savings": "$18,000/month",
                "revenue_increase": "$45,000/month",
                "payback_period": "2 weeks",
            },
            "comparison": {
                "hiring_employees": "$15,000/month (3 FTEs)",
                "traditional_agency": "$12,000/month",
                "nexusai_automation": f"${template['price']}/month",
            },
        }

        return explanation

    async def _onboard_client(self, params: Dict) -> Dict:
        """Automate client onboarding"""
        client_id = params.get("client_id")

        onboarding_steps = [
            {"step": 1, "action": "Create client portal account", "status": "completed"},
            {"step": 2, "action": "Configure AI agents for industry", "status": "completed"},
            {"step": 3, "action": "Import existing CRM data", "status": "in_progress"},
            {"step": 4, "action": "Setup Gmail integration", "status": "pending"},
            {"step": 5, "action": "Configure workflow triggers", "status": "pending"},
            {"step": 6, "action": "Schedule kickoff call", "status": "pending"},
            {"step": 7, "action": "Deliver training materials", "status": "pending"},
        ]

        return {
            "client_id": client_id,
            "onboarding_id": f"onb_{datetime.utcnow().timestamp()}",
            "steps": onboarding_steps,
            "progress": 28,  # Percentage
            "estimated_completion": (datetime.utcnow() + timedelta(hours=24)).isoformat(),
        }
