"""
NexusAI Agent Orchestrator Service
Multi-agent collaboration system for autonomous business operations
"""

import os
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

from agents.lead_generation import LeadGenerationAgent
from agents.outreach import OutreachAgent
from agents.sales import SalesAgent
from agents.support import SupportAgent
from agents.content import ContentAgent
from agents.analytics import AnalyticsAgent
from agents.optimization import OptimizationAgent
from memory.vector_store import VectorStore
from memory.redis_cache import RedisCache
from workflows.orchestrator import WorkflowOrchestrator

# Configuration
AGENT_CONFIG = {
    "openai_api_key": os.getenv("OPENAI_API_KEY"),
    "anthropic_api_key": os.getenv("ANTHROPIC_API_KEY"),
    "google_ai_key": os.getenv("GOOGLE_AI_API_KEY"),
    "pinecone_api_key": os.getenv("PINECONE_API_KEY"),
    "pinecone_index": os.getenv("PINECONE_INDEX", "ai-business-memory"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
}

# Initialize services
vector_store = VectorStore(AGENT_CONFIG)
redis_cache = RedisCache(AGENT_CONFIG)
orchestrator = WorkflowOrchestrator()

# Agent registry
agents = {
    "lead": LeadGenerationAgent(AGENT_CONFIG, vector_store, redis_cache),
    "outreach": OutreachAgent(AGENT_CONFIG, vector_store, redis_cache),
    "sales": SalesAgent(AGENT_CONFIG, vector_store, redis_cache),
    "support": SupportAgent(AGENT_CONFIG, vector_store, redis_cache),
    "content": ContentAgent(AGENT_CONFIG, vector_store, redis_cache),
    "analytics": AnalyticsAgent(AGENT_CONFIG, vector_store, redis_cache),
    "optimization": OptimizationAgent(AGENT_CONFIG, vector_store, redis_cache),
}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events"""
    # Startup
    print("🚀 NexusAI Agent Orchestrator starting...")
    await vector_store.initialize()
    await redis_cache.connect()

    # Initialize all agents
    for name, agent in agents.items():
        await agent.initialize()
        print(f"  ✓ {name} agent initialized")

    # Start background workflow scheduler
    asyncio.create_task(workflow_scheduler())

    yield

    # Shutdown
    print("🛑 Shutting down...")
    for agent in agents.values():
        await agent.shutdown()
    await redis_cache.disconnect()

app = FastAPI(
    title="NexusAI Agent Orchestrator",
    description="Multi-agent collaboration system for autonomous business operations",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic Models
class AgentActionRequest(BaseModel):
    user_id: str
    config: Optional[Dict[str, Any]] = None

class WorkflowExecuteRequest(BaseModel):
    user_id: str
    workflow_id: str
    parameters: Optional[Dict[str, Any]] = None

class LeadDiscoveryRequest(BaseModel):
    user_id: str
    sources: List[str] = ["linkedin", "crunchbase", "apollo"]
    industries: List[str] = ["SaaS", "AI/ML", "Fintech"]
    company_size: List[str] = ["11-50", "51-200", "201-500"]
    max_leads: int = 100

class OutreachRequest(BaseModel):
    user_id: str
    lead_ids: List[str]
    template_id: Optional[str] = None
    personalized: bool = True

class ContentGenerateRequest(BaseModel):
    user_id: str
    topic: str
    platforms: List[str] = ["blog", "linkedin", "twitter"]
    tone: str = "professional"
    seo_optimize: bool = True

# Background task: Workflow scheduler
async def workflow_scheduler():
    """Periodically execute scheduled workflows"""
    while True:
        try:
            # Check for scheduled workflows
            scheduled = await redis_cache.get_scheduled_workflows()
            for workflow in scheduled:
                if orchestrator.should_execute(workflow):
                    await orchestrator.execute_workflow(workflow, agents)

            await asyncio.sleep(60)  # Check every minute
        except Exception as e:
            print(f"Scheduler error: {e}")
            await asyncio.sleep(60)

# Health check
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "agents": {name: agent.status for name, agent in agents.items()},
    }

# Agent Management
@app.get("/agents")
async def list_agents():
    """List all available agents and their status"""
    return {
        "agents": [
            {
                "id": name,
                "name": agent.name,
                "status": agent.status,
                "description": agent.description,
                "metrics": agent.get_metrics(),
            }
            for name, agent in agents.items()
        ]
    }

@app.post("/agents/{agent_id}/start")
async def start_agent(agent_id: str, request: AgentActionRequest):
    """Start a specific agent"""
    if agent_id not in agents:
        raise HTTPException(status_code=404, detail="Agent not found")

    agent = agents[agent_id]
    await agent.start(request.config)

    return {
        "agent_id": agent_id,
        "status": agent.status,
        "message": f"{agent.name} started successfully",
    }

@app.post("/agents/{agent_id}/stop")
async def stop_agent(agent_id: str, request: AgentActionRequest):
    """Stop a specific agent"""
    if agent_id not in agents:
        raise HTTPException(status_code=404, detail="Agent not found")

    agent = agents[agent_id]
    await agent.stop()

    return {
        "agent_id": agent_id,
        "status": agent.status,
        "message": f"{agent.name} stopped successfully",
    }

@app.post("/agents/{agent_id}/execute")
async def execute_agent(agent_id: str, request: AgentActionRequest, background_tasks: BackgroundTasks):
    """Execute a specific agent task"""
    if agent_id not in agents:
        raise HTTPException(status_code=404, detail="Agent not found")

    agent = agents[agent_id]

    # Execute in background for non-blocking response
    background_tasks.add_task(agent.execute, request.config)

    return {
        "agent_id": agent_id,
        "status": "executing",
        "message": f"{agent.name} task queued for execution",
    }

# Workflow Management
@app.get("/workflows")
async def list_workflows():
    """List all configured workflows"""
    return {"workflows": orchestrator.list_workflows()}

@app.post("/workflows/execute")
async def execute_workflow(request: WorkflowExecuteRequest, background_tasks: BackgroundTasks):
    """Execute a workflow"""
    workflow = orchestrator.get_workflow(request.workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")

    # Execute workflow in background
    background_tasks.add_task(
        orchestrator.execute_workflow,
        workflow,
        agents,
        request.parameters
    )

    return {
        "workflow_id": request.workflow_id,
        "status": "executing",
        "message": "Workflow execution started",
    }

# Lead Generation Endpoints
@app.post("/leads/discover")
async def discover_leads(request: LeadDiscoveryRequest, background_tasks: BackgroundTasks):
    """Trigger lead discovery"""
    agent = agents["lead"]

    background_tasks.add_task(
        agent.discover_leads,
        sources=request.sources,
        industries=request.industries,
        company_size=request.company_size,
        max_leads=request.max_leads,
    )

    return {
        "status": "discovering",
        "message": f"Lead discovery started for {request.max_leads} leads",
        "parameters": {
            "sources": request.sources,
            "industries": request.industries,
        },
    }

@app.get("/leads")
async def get_leads(
    status: Optional[str] = None,
    industry: Optional[str] = None,
    min_score: Optional[int] = None,
    limit: int = 50,
):
    """Get discovered leads with filters"""
    agent = agents["lead"]
    leads = await agent.get_leads(
        status=status,
        industry=industry,
        min_score=min_score,
        limit=limit,
    )
    return {"leads": leads, "total": len(leads)}

# Outreach Endpoints
@app.post("/outreach/send")
async def send_outreach(request: OutreachRequest, background_tasks: BackgroundTasks):
    """Send personalized outreach"""
    agent = agents["outreach"]

    background_tasks.add_task(
        agent.send_outreach,
        lead_ids=request.lead_ids,
        template_id=request.template_id,
        personalized=request.personalized,
    )

    return {
        "status": "sending",
        "message": f"Outreach queued for {len(request.lead_ids)} leads",
    }

@app.get("/outreach/sequences")
async def get_sequences():
    """Get active outreach sequences"""
    agent = agents["outreach"]
    return {"sequences": await agent.get_sequences()}

# Content Generation
@app.post("/content/generate")
async def generate_content(request: ContentGenerateRequest, background_tasks: BackgroundTasks):
    """Generate multi-platform content"""
    agent = agents["content"]

    background_tasks.add_task(
        agent.generate_content,
        topic=request.topic,
        platforms=request.platforms,
        tone=request.tone,
        seo_optimize=request.seo_optimize,
    )

    return {
        "status": "generating",
        "message": f"Content generation started for: {request.topic}",
        "platforms": request.platforms,
    }

@app.get("/content/queue")
async def get_content_queue():
    """Get content production queue"""
    agent = agents["content"]
    return {"queue": await agent.get_queue()}

# Analytics & Reporting
@app.get("/analytics/dashboard")
async def get_analytics_dashboard(period: str = "30d"):
    """Get analytics dashboard data"""
    agent = agents["analytics"]
    return await agent.get_dashboard_data(period)

@app.post("/analytics/report")
async def generate_report(user_id: str, report_type: str = "daily"):
    """Generate and send analytics report"""
    agent = agents["analytics"]
    report = await agent.generate_report(report_type)

    # Send to Gmail Hub
    await agents["outreach"].send_gmail_summary(user_id, report)

    return {
        "status": "generated",
        "report_type": report_type,
        "message": "Report generated and sent to Gmail",
    }

# Gmail Hub Integration
@app.post("/gmail/send")
async def send_gmail_notification(user_id: str, category: str, subject: str, content: str):
    """Send notification via Gmail Hub"""
    agent = agents["outreach"]
    result = await agent.send_gmail_notification(user_id, category, subject, content)
    return {"status": "sent", "message": "Notification sent via Gmail"}

@app.get("/gmail/summary")
async def get_gmail_summary(user_id: str, period: str = "today"):
    """Get Gmail summary for user"""
    # Retrieve from Gmail Hub service
    return {
        "period": period,
        "summary": {
            "lead_alerts": 12,
            "sales_updates": 8,
            "daily_reports": 1,
            "support_tickets": 5,
            "system_alerts": 3,
        },
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
