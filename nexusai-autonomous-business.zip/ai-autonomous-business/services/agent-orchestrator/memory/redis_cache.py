"""
Redis Cache — Fast in-memory storage for agent state and queues
"""

from typing import Dict, List, Optional, Any
import json

class RedisCache:
    """Redis-based caching for agent operations"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.client = None
        self._memory = {}  # In-memory fallback

    async def connect(self):
        """Connect to Redis"""
        try:
            import redis.asyncio as redis
            self.client = redis.from_url(
                self.config.get("redis_url", "redis://localhost:6379"),
                decode_responses=True,
            )
            await self.client.ping()
            print("  ✓ Redis cache connected")
        except ImportError:
            print("  ⚠ Redis not available — using in-memory fallback")
            self.client = None

    async def disconnect(self):
        """Disconnect from Redis"""
        if self.client:
            await self.client.close()

    async def get(self, key: str) -> Optional[Dict]:
        """Get value from cache"""
        if self.client:
            value = await self.client.get(key)
            return json.loads(value) if value else None
        return self._memory.get(key)

    async def set(self, key: str, value: Any, ttl: int = 3600):
        """Set value in cache with TTL"""
        serialized = json.dumps(value, default=str)
        if self.client:
            await self.client.setex(key, ttl, serialized)
        else:
            self._memory[key] = json.loads(serialized)

    async def delete(self, key: str):
        """Delete value from cache"""
        if self.client:
            await self.client.delete(key)
        else:
            self._memory.pop(key, None)

    async def get_scheduled_workflows(self) -> List[Dict]:
        """Get scheduled workflows"""
        # In production, query from Redis sorted sets
        return []
