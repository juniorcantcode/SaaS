"""
Workflow Orchestrator — DAG-based multi-agent pipeline execution
"""

from typing import Dict, List, Optional, Any
from datetime import datetime
import asyncio

class WorkflowOrchestrator:
    """Orchestrates multi-agent workflows with dependency management"""

    def __init__(self):
        self.workflows = self._load_workflows()
        self.executions = {}

    def _load_workflows(self) -> Dict[str, Dict]:
        """Load workflow definitions"""
        return {
            "wf-001": {
                "id": "wf-001",
                "name": "Lead Discovery → Qualification → CRM",
                "description": "Automatically discovers leads, enriches data, scores them, and inserts into CRM",
                "steps": [
                    {"id": "step-1", "agent": "lead", "action": "discover", "depends_on": []},
                    {"id": "step-2", "agent": "lead", "action": "enrich", "depends_on": ["step-1"]},
                    {"id": "step-3", "agent": "lead", "action": "qualify", "depends_on": ["step-2"]},
                    {"id": "step-4", "agent": "crm", "action": "insert", "depends_on": ["step-3"]},
                ],
                "triggers": ["schedule", "manual"],
            },
            "wf-002": {
                "id": "wf-002",
                "name": "Outreach Sequence Automation",
                "description": "Sends personalized emails with automated follow-ups based on engagement",
                "steps": [
                    {"id": "step-1", "agent": "lead", "action": "get_qualified", "depends_on": []},
                    {"id": "step-2", "agent": "outreach", "action": "generate", "depends_on": ["step-1"]},
                    {"id": "step-3", "agent": "outreach", "action": "send", "depends_on": ["step-2"]},
                    {"id": "step-4", "agent": "outreach", "action": "track", "depends_on": ["step-3"]},
                    {"id": "step-5", "agent": "outreach", "action": "follow_up", "depends_on": ["step-4"]},
                ],
                "triggers": ["new-lead", "manual"],
            },
            "wf-003": {
                "id": "wf-003",
                "name": "Sales → Proposal → Onboarding",
                "description": "Handles sales conversations, generates proposals, and automates client onboarding",
                "steps": [
                    {"id": "step-1", "agent": "sales", "action": "analyze", "depends_on": []},
                    {"id": "step-2", "agent": "sales", "action": "generate_proposal", "depends_on": ["step-1"]},
                    {"id": "step-3", "agent": "sales", "action": "send", "depends_on": ["step-2"]},
                    {"id": "step-4", "agent": "sales", "action": "track", "depends_on": ["step-3"]},
                    {"id": "step-5", "agent": "sales", "action": "onboard", "depends_on": ["step-4"]},
                ],
                "triggers": ["meeting-booked", "proposal-request"],
            },
            "wf-004": {
                "id": "wf-004",
                "name": "Content Production Pipeline",
                "description": "Generates, optimizes, and publishes content across all platforms",
                "steps": [
                    {"id": "step-1", "agent": "content", "action": "research", "depends_on": []},
                    {"id": "step-2", "agent": "content", "action": "generate", "depends_on": ["step-1"]},
                    {"id": "step-3", "agent": "content", "action": "repurpose", "depends_on": ["step-2"]},
                    {"id": "step-4", "agent": "content", "action": "optimize_seo", "depends_on": ["step-3"]},
                    {"id": "step-5", "agent": "content", "action": "schedule", "depends_on": ["step-4"]},
                ],
                "triggers": ["schedule", "trending-topic"],
            },
            "wf-005": {
                "id": "wf-005",
                "name": "Daily Analytics & Reporting",
                "description": "Compiles KPIs, detects anomalies, and sends executive summary to Gmail",
                "steps": [
                    {"id": "step-1", "agent": "analytics", "action": "collect", "depends_on": []},
                    {"id": "step-2", "agent": "analytics", "action": "detect_anomalies", "depends_on": ["step-1"]},
                    {"id": "step-3", "agent": "analytics", "action": "generate_insights", "depends_on": ["step-2"]},
                    {"id": "step-4", "agent": "analytics", "action": "compile_report", "depends_on": ["step-3"]},
                    {"id": "step-5", "agent": "outreach", "action": "send_gmail", "depends_on": ["step-4"]},
                ],
                "triggers": ["schedule", "anomaly-detected"],
            },
            "wf-006": {
                "id": "wf-006",
                "name": "Support Ticket Auto-Resolution",
                "description": "Automatically resolves common support tickets and escalates complex issues",
                "steps": [
                    {"id": "step-1", "agent": "support", "action": "classify", "depends_on": []},
                    {"id": "step-2", "agent": "support", "action": "search_kb", "depends_on": ["step-1"]},
                    {"id": "step-3", "agent": "support", "action": "generate_response", "depends_on": ["step-2"]},
                    {"id": "step-4", "agent": "support", "action": "resolve_or_escalate", "depends_on": ["step-3"]},
                ],
                "triggers": ["new-ticket", "manual"],
            },
        }

    def list_workflows(self) -> List[Dict]:
        """List all workflows"""
        return list(self.workflows.values())

    def get_workflow(self, workflow_id: str) -> Optional[Dict]:
        """Get workflow by ID"""
        return self.workflows.get(workflow_id)

    def should_execute(self, workflow: Dict) -> bool:
        """Check if workflow should execute based on schedule"""
        # In production, check cron schedule
        return True

    async def execute_workflow(self, workflow: Dict, agents: Dict, parameters: Optional[Dict] = None):
        """Execute workflow with agent orchestration"""
        execution_id = f"exec_{datetime.utcnow().timestamp()}"

        # Build dependency graph
        steps = workflow.get("steps", [])
        completed = set()
        results = {}

        async def execute_step(step):
            """Execute a single workflow step"""
            # Wait for dependencies
            for dep in step.get("depends_on", []):
                while dep not in completed:
                    await asyncio.sleep(0.1)

            # Get agent
            agent_name = step.get("agent")
            agent = agents.get(agent_name)

            if not agent:
                results[step["id"]] = {"error": f"Agent {agent_name} not found"}
                completed.add(step["id"])
                return

            # Execute step
            try:
                result = await agent.execute({
                    "action": step.get("action"),
                    **(parameters or {}),
                })
                results[step["id"]] = result
            except Exception as e:
                results[step["id"]] = {"error": str(e)}

            completed.add(step["id"])

        # Execute all steps concurrently respecting dependencies
        tasks = [execute_step(step) for step in steps]
        await asyncio.gather(*tasks)

        # Store execution results
        self.executions[execution_id] = {
            "workflow_id": workflow["id"],
            "started_at": datetime.utcnow().isoformat(),
            "completed_at": datetime.utcnow().isoformat(),
            "results": results,
            "status": "completed",
        }

        return self.executions[execution_id]
